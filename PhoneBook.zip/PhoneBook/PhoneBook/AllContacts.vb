﻿Imports MySql.Data.MySqlClient
Public Class AllContacts
    Dim MysqlConn As MySqlConnection
    Dim command As MySqlCommand
     Dim con As MySqlConnection
    Private Sub AllContacts_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        load_table()
    End Sub
    Public Sub load_table()
        MysqlConn = New MySqlConnection
        MysqlConn.ConnectionString = " datasource=127.0.0.1;port=3306;user=root;password=;database=bunifuphonebook;SslMode=none"

        Dim SDA As New MySqlDataAdapter
        Dim bsource As New BindingSource
        Dim dbDataSet As New DataTable
        Try
            MysqlConn.Open()
            Dim Query As String
            Query = "select * from bunifuphonebook.users"
            command = New MySqlCommand(Query, MysqlConn)
            SDA.SelectCommand = command
            SDA.Fill(dbDataSet)
            bsource.DataSource = dbDataSet
            BunifuCustomDataGrid1.DataSource = bsource
            SDA.Update(dbDataSet)
            MysqlConn.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

        CType(BunifuCustomDataGrid1.Columns(1), DataGridViewImageColumn).ImageLayout = DataGridViewImageCellLayout.Stretch
        CType(BunifuCustomDataGrid1.Columns(1), DataGridViewImageColumn).Width = 35

    End Sub

    Private Sub BunifuImageButton5_Click(sender As Object, e As EventArgs) Handles BunifuImageButton5.Click
        con = New MySqlConnection



        If Me.BunifuCustomDataGrid1.Rows.Count = 0 OrElse Me.BunifuCustomDataGrid1.SelectedRows.Count = 0 Then
            Exit Sub
        End If

        Dim res As DialogResult = MsgBox("Are you sure you want to DELETE the selected Contact?", MessageBoxButtons.YesNo)
        If res <> DialogResult.Yes Then Exit Sub

        Dim intStdID As Char = Me.BunifuCustomDataGrid1.SelectedRows(0).Cells("name").Value
        Dim MySQL As String = "DELETE  FROM bunifuphonebook.users WHERE name= '" & TextBox1.Text & "' "

        Using con As New MySqlConnection("datasource=127.0.0.1;userid=root;password=;database=bunifuphonebook;SslMode=none"),
              cmd As New MySqlCommand(MySQL, con)

            cmd.Parameters.Add("@name", MySqlDbType.Text, 1).Value = intStdID
            con.Open()
            cmd.ExecuteNonQuery()
        End Using
        load_table()
    End Sub





    Private Sub BunifuImageButton1_Click(sender As Object, e As EventArgs) Handles BunifuImageButton1.Click
        MysqlConn = New MySqlConnection
        MysqlConn.ConnectionString = " datasource=127.0.0.1;port=3306;user=root;password=;database=bunifuphonebook;SslMode=none"
        MysqlConn.Open()
        command = New MySqlCommand("select * from bunifuphonebook.users where name=@name", MysqlConn)
        command.Parameters.Add("@name", MySqlDbType.Text).Value = BunifuTextBox1.Text

        Dim SDA As New MySqlDataAdapter
        SDA.SelectCommand = command
        Dim dt As DataTable = New DataTable()
        SDA.Fill(dt)
        If (dt.Rows.Count() > 0) Then
            BunifuCustomDataGrid1.DataSource = dt
            Dim i As Integer
            i = BunifuCustomDataGrid1.CurrentRow.Index
            Try
                TextBox1.Text = BunifuCustomDataGrid1.Item(2, i).Value


            Catch ex As Exception

            End Try
        Else
            MsgBox("Contact not found")

        End If
    End Sub

    Private Sub BunifuImageButton2_Click(sender As Object, e As EventArgs) Handles BunifuImageButton2.Click
        Me.Controls.Clear()
        InitializeComponent()
        AllContacts_Load(e, e)
        Refresh()
    End Sub

    Private Sub BunifuDataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)

    End Sub

    Private Sub BunifuCustomDataGrid1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles BunifuCustomDataGrid1.CellContentClick

    End Sub

    Private Sub BunifuCustomDataGrid1_Click(sender As Object, e As EventArgs) Handles BunifuCustomDataGrid1.Click
        Dim i As Integer
        i = BunifuCustomDataGrid1.CurrentRow.Index
        Try
            TextBox1.Text = BunifuCustomDataGrid1.Item(2, i).Value

        Catch ex As Exception
            MsgBox("Sorry exception occured")
        End Try
    End Sub
End Class
