﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AddContact
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(AddContact))
        Dim StateProperties1 As Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties = New Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties()
        Dim StateProperties2 As Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties = New Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties()
        Me.BunifuLabel2 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuPictureBox1 = New Bunifu.UI.WinForms.BunifuPictureBox()
        Me.BunifuButton1 = New Bunifu.UI.WinForms.BunifuButton.BunifuButton()
        Me.BunifuTextBox1 = New Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox()
        Me.BunifuTextBox2 = New Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox()
        Me.BunifuTextBox3 = New Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox()
        Me.BunifuTextBox4 = New Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox()
        Me.BunifuButton2 = New Bunifu.UI.WinForms.BunifuButton.BunifuButton()
        Me.lblerror = New Bunifu.Framework.UI.BunifuCustomLabel()
        CType(Me.BunifuPictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BunifuLabel2
        '
        Me.BunifuLabel2.AutoEllipsis = False
        Me.BunifuLabel2.CursorType = Nothing
        Me.BunifuLabel2.Font = New System.Drawing.Font("Yu Gothic UI", 15.75!, System.Drawing.FontStyle.Bold)
        Me.BunifuLabel2.ForeColor = System.Drawing.Color.Salmon
        Me.BunifuLabel2.Location = New System.Drawing.Point(177, 29)
        Me.BunifuLabel2.Name = "BunifuLabel2"
        Me.BunifuLabel2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel2.Size = New System.Drawing.Size(173, 32)
        Me.BunifuLabel2.TabIndex = 4
        Me.BunifuLabel2.Text = "Add New Contact"
        Me.BunifuLabel2.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        '
        'BunifuPictureBox1
        '
        Me.BunifuPictureBox1.AllowFocused = False
        Me.BunifuPictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.BunifuPictureBox1.BorderRadius = 37
        Me.BunifuPictureBox1.Image = CType(resources.GetObject("BunifuPictureBox1.Image"), System.Drawing.Image)
        Me.BunifuPictureBox1.IsCircle = True
        Me.BunifuPictureBox1.Location = New System.Drawing.Point(177, 91)
        Me.BunifuPictureBox1.Name = "BunifuPictureBox1"
        Me.BunifuPictureBox1.Size = New System.Drawing.Size(75, 75)
        Me.BunifuPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.BunifuPictureBox1.TabIndex = 9
        Me.BunifuPictureBox1.TabStop = False
        Me.BunifuPictureBox1.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Square
        '
        'BunifuButton1
        '
        Me.BunifuButton1.BackColor = System.Drawing.Color.Transparent
        Me.BunifuButton1.BackgroundImage = CType(resources.GetObject("BunifuButton1.BackgroundImage"), System.Drawing.Image)
        Me.BunifuButton1.ButtonText = "Choose image..."
        Me.BunifuButton1.ButtonTextMarginLeft = 0
        Me.BunifuButton1.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(161, Byte), Integer))
        Me.BunifuButton1.DisabledFillColor = System.Drawing.Color.Gray
        Me.BunifuButton1.DisabledForecolor = System.Drawing.Color.White
        Me.BunifuButton1.ForeColor = System.Drawing.Color.White
        Me.BunifuButton1.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.BunifuButton1.IconPadding = 10
        Me.BunifuButton1.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.BunifuButton1.IdleBorderColor = System.Drawing.Color.Silver
        Me.BunifuButton1.IdleBorderRadius = 25
        Me.BunifuButton1.IdleBorderThickness = 0
        Me.BunifuButton1.IdleFillColor = System.Drawing.Color.Silver
        Me.BunifuButton1.IdleIconLeftImage = Nothing
        Me.BunifuButton1.IdleIconRightImage = Nothing
        Me.BunifuButton1.Location = New System.Drawing.Point(258, 138)
        Me.BunifuButton1.Name = "BunifuButton1"
        StateProperties1.BorderColor = System.Drawing.Color.Silver
        StateProperties1.BorderRadius = 1
        StateProperties1.BorderThickness = 1
        StateProperties1.FillColor = System.Drawing.Color.Silver
        StateProperties1.IconLeftImage = Nothing
        StateProperties1.IconRightImage = Nothing
        Me.BunifuButton1.onHoverState = StateProperties1
        Me.BunifuButton1.Size = New System.Drawing.Size(111, 28)
        Me.BunifuButton1.TabIndex = 10
        Me.BunifuButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuTextBox1
        '
        Me.BunifuTextBox1.AcceptsReturn = False
        Me.BunifuTextBox1.AcceptsTab = False
        Me.BunifuTextBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.BunifuTextBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.BunifuTextBox1.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTextBox1.BackgroundImage = CType(resources.GetObject("BunifuTextBox1.BackgroundImage"), System.Drawing.Image)
        Me.BunifuTextBox1.BorderColorActive = System.Drawing.Color.Salmon
        Me.BunifuTextBox1.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(161, Byte), Integer))
        Me.BunifuTextBox1.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.BunifuTextBox1.BorderColorIdle = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(107, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.BunifuTextBox1.BorderRadius = 25
        Me.BunifuTextBox1.BorderThickness = 1
        Me.BunifuTextBox1.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.BunifuTextBox1.DefaultFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuTextBox1.DefaultText = ""
        Me.BunifuTextBox1.FillColor = System.Drawing.Color.White
        Me.BunifuTextBox1.HideSelection = True
        Me.BunifuTextBox1.IconLeft = Nothing
        Me.BunifuTextBox1.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.BunifuTextBox1.IconPadding = 10
        Me.BunifuTextBox1.IconRight = Nothing
        Me.BunifuTextBox1.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.BunifuTextBox1.Location = New System.Drawing.Point(139, 185)
        Me.BunifuTextBox1.MaxLength = 32767
        Me.BunifuTextBox1.MinimumSize = New System.Drawing.Size(100, 35)
        Me.BunifuTextBox1.Modified = False
        Me.BunifuTextBox1.Name = "BunifuTextBox1"
        Me.BunifuTextBox1.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.BunifuTextBox1.ReadOnly = False
        Me.BunifuTextBox1.SelectedText = ""
        Me.BunifuTextBox1.SelectionLength = 0
        Me.BunifuTextBox1.SelectionStart = 0
        Me.BunifuTextBox1.ShortcutsEnabled = True
        Me.BunifuTextBox1.Size = New System.Drawing.Size(240, 35)
        Me.BunifuTextBox1.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu
        Me.BunifuTextBox1.TabIndex = 11
        Me.BunifuTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.BunifuTextBox1.TextMarginLeft = 5
        Me.BunifuTextBox1.TextPlaceholder = "name"
        Me.BunifuTextBox1.UseSystemPasswordChar = False
        '
        'BunifuTextBox2
        '
        Me.BunifuTextBox2.AcceptsReturn = False
        Me.BunifuTextBox2.AcceptsTab = False
        Me.BunifuTextBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.BunifuTextBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.BunifuTextBox2.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTextBox2.BackgroundImage = CType(resources.GetObject("BunifuTextBox2.BackgroundImage"), System.Drawing.Image)
        Me.BunifuTextBox2.BorderColorActive = System.Drawing.Color.Salmon
        Me.BunifuTextBox2.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(161, Byte), Integer))
        Me.BunifuTextBox2.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.BunifuTextBox2.BorderColorIdle = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(107, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.BunifuTextBox2.BorderRadius = 25
        Me.BunifuTextBox2.BorderThickness = 1
        Me.BunifuTextBox2.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.BunifuTextBox2.DefaultFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuTextBox2.DefaultText = ""
        Me.BunifuTextBox2.FillColor = System.Drawing.Color.White
        Me.BunifuTextBox2.HideSelection = True
        Me.BunifuTextBox2.IconLeft = Nothing
        Me.BunifuTextBox2.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.BunifuTextBox2.IconPadding = 10
        Me.BunifuTextBox2.IconRight = Nothing
        Me.BunifuTextBox2.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.BunifuTextBox2.Location = New System.Drawing.Point(139, 250)
        Me.BunifuTextBox2.MaxLength = 32767
        Me.BunifuTextBox2.MinimumSize = New System.Drawing.Size(100, 35)
        Me.BunifuTextBox2.Modified = False
        Me.BunifuTextBox2.Name = "BunifuTextBox2"
        Me.BunifuTextBox2.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.BunifuTextBox2.ReadOnly = False
        Me.BunifuTextBox2.SelectedText = ""
        Me.BunifuTextBox2.SelectionLength = 0
        Me.BunifuTextBox2.SelectionStart = 0
        Me.BunifuTextBox2.ShortcutsEnabled = True
        Me.BunifuTextBox2.Size = New System.Drawing.Size(240, 35)
        Me.BunifuTextBox2.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu
        Me.BunifuTextBox2.TabIndex = 12
        Me.BunifuTextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.BunifuTextBox2.TextMarginLeft = 5
        Me.BunifuTextBox2.TextPlaceholder = "contact no."
        Me.BunifuTextBox2.UseSystemPasswordChar = False
        '
        'BunifuTextBox3
        '
        Me.BunifuTextBox3.AcceptsReturn = False
        Me.BunifuTextBox3.AcceptsTab = False
        Me.BunifuTextBox3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.BunifuTextBox3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.BunifuTextBox3.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTextBox3.BackgroundImage = CType(resources.GetObject("BunifuTextBox3.BackgroundImage"), System.Drawing.Image)
        Me.BunifuTextBox3.BorderColorActive = System.Drawing.Color.Salmon
        Me.BunifuTextBox3.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(161, Byte), Integer))
        Me.BunifuTextBox3.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.BunifuTextBox3.BorderColorIdle = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(107, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.BunifuTextBox3.BorderRadius = 25
        Me.BunifuTextBox3.BorderThickness = 1
        Me.BunifuTextBox3.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.BunifuTextBox3.DefaultFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuTextBox3.DefaultText = ""
        Me.BunifuTextBox3.FillColor = System.Drawing.Color.White
        Me.BunifuTextBox3.HideSelection = True
        Me.BunifuTextBox3.IconLeft = Nothing
        Me.BunifuTextBox3.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.BunifuTextBox3.IconPadding = 10
        Me.BunifuTextBox3.IconRight = Nothing
        Me.BunifuTextBox3.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.BunifuTextBox3.Location = New System.Drawing.Point(139, 319)
        Me.BunifuTextBox3.MaxLength = 32767
        Me.BunifuTextBox3.MinimumSize = New System.Drawing.Size(100, 35)
        Me.BunifuTextBox3.Modified = False
        Me.BunifuTextBox3.Name = "BunifuTextBox3"
        Me.BunifuTextBox3.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.BunifuTextBox3.ReadOnly = False
        Me.BunifuTextBox3.SelectedText = ""
        Me.BunifuTextBox3.SelectionLength = 0
        Me.BunifuTextBox3.SelectionStart = 0
        Me.BunifuTextBox3.ShortcutsEnabled = True
        Me.BunifuTextBox3.Size = New System.Drawing.Size(240, 35)
        Me.BunifuTextBox3.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu
        Me.BunifuTextBox3.TabIndex = 13
        Me.BunifuTextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.BunifuTextBox3.TextMarginLeft = 5
        Me.BunifuTextBox3.TextPlaceholder = "country"
        Me.BunifuTextBox3.UseSystemPasswordChar = False
        '
        'BunifuTextBox4
        '
        Me.BunifuTextBox4.AcceptsReturn = False
        Me.BunifuTextBox4.AcceptsTab = False
        Me.BunifuTextBox4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.BunifuTextBox4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.BunifuTextBox4.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTextBox4.BackgroundImage = CType(resources.GetObject("BunifuTextBox4.BackgroundImage"), System.Drawing.Image)
        Me.BunifuTextBox4.BorderColorActive = System.Drawing.Color.Salmon
        Me.BunifuTextBox4.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(161, Byte), Integer))
        Me.BunifuTextBox4.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.BunifuTextBox4.BorderColorIdle = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(107, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.BunifuTextBox4.BorderRadius = 25
        Me.BunifuTextBox4.BorderThickness = 1
        Me.BunifuTextBox4.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.BunifuTextBox4.DefaultFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuTextBox4.DefaultText = ""
        Me.BunifuTextBox4.FillColor = System.Drawing.Color.White
        Me.BunifuTextBox4.HideSelection = True
        Me.BunifuTextBox4.IconLeft = Nothing
        Me.BunifuTextBox4.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.BunifuTextBox4.IconPadding = 10
        Me.BunifuTextBox4.IconRight = Nothing
        Me.BunifuTextBox4.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.BunifuTextBox4.Location = New System.Drawing.Point(139, 379)
        Me.BunifuTextBox4.MaxLength = 32767
        Me.BunifuTextBox4.MinimumSize = New System.Drawing.Size(100, 35)
        Me.BunifuTextBox4.Modified = False
        Me.BunifuTextBox4.Name = "BunifuTextBox4"
        Me.BunifuTextBox4.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.BunifuTextBox4.ReadOnly = False
        Me.BunifuTextBox4.SelectedText = ""
        Me.BunifuTextBox4.SelectionLength = 0
        Me.BunifuTextBox4.SelectionStart = 0
        Me.BunifuTextBox4.ShortcutsEnabled = True
        Me.BunifuTextBox4.Size = New System.Drawing.Size(240, 35)
        Me.BunifuTextBox4.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu
        Me.BunifuTextBox4.TabIndex = 14
        Me.BunifuTextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.BunifuTextBox4.TextMarginLeft = 5
        Me.BunifuTextBox4.TextPlaceholder = "state"
        Me.BunifuTextBox4.UseSystemPasswordChar = False
        '
        'BunifuButton2
        '
        Me.BunifuButton2.BackColor = System.Drawing.Color.Transparent
        Me.BunifuButton2.BackgroundImage = CType(resources.GetObject("BunifuButton2.BackgroundImage"), System.Drawing.Image)
        Me.BunifuButton2.ButtonText = "Add"
        Me.BunifuButton2.ButtonTextMarginLeft = 0
        Me.BunifuButton2.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(161, Byte), Integer))
        Me.BunifuButton2.DisabledFillColor = System.Drawing.Color.Gray
        Me.BunifuButton2.DisabledForecolor = System.Drawing.Color.White
        Me.BunifuButton2.ForeColor = System.Drawing.Color.White
        Me.BunifuButton2.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.BunifuButton2.IconPadding = 10
        Me.BunifuButton2.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.BunifuButton2.IdleBorderColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(183, Byte), Integer))
        Me.BunifuButton2.IdleBorderRadius = 25
        Me.BunifuButton2.IdleBorderThickness = 0
        Me.BunifuButton2.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(183, Byte), Integer))
        Me.BunifuButton2.IdleIconLeftImage = Nothing
        Me.BunifuButton2.IdleIconRightImage = Nothing
        Me.BunifuButton2.Location = New System.Drawing.Point(139, 440)
        Me.BunifuButton2.Name = "BunifuButton2"
        StateProperties2.BorderColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        StateProperties2.BorderRadius = 25
        StateProperties2.BorderThickness = 1
        StateProperties2.FillColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        StateProperties2.IconLeftImage = Nothing
        StateProperties2.IconRightImage = Nothing
        Me.BunifuButton2.onHoverState = StateProperties2
        Me.BunifuButton2.Size = New System.Drawing.Size(240, 45)
        Me.BunifuButton2.TabIndex = 15
        Me.BunifuButton2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblerror
        '
        Me.lblerror.AutoSize = True
        Me.lblerror.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblerror.ForeColor = System.Drawing.Color.Red
        Me.lblerror.Location = New System.Drawing.Point(221, 501)
        Me.lblerror.Name = "lblerror"
        Me.lblerror.Size = New System.Drawing.Size(50, 16)
        Me.lblerror.TabIndex = 16
        Me.lblerror.Text = "lblerror"
        '
        'AddContact
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.lblerror)
        Me.Controls.Add(Me.BunifuButton2)
        Me.Controls.Add(Me.BunifuTextBox4)
        Me.Controls.Add(Me.BunifuTextBox3)
        Me.Controls.Add(Me.BunifuTextBox2)
        Me.Controls.Add(Me.BunifuTextBox1)
        Me.Controls.Add(Me.BunifuButton1)
        Me.Controls.Add(Me.BunifuPictureBox1)
        Me.Controls.Add(Me.BunifuLabel2)
        Me.Name = "AddContact"
        Me.Size = New System.Drawing.Size(546, 553)
        CType(Me.BunifuPictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents BunifuLabel2 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuPictureBox1 As Bunifu.UI.WinForms.BunifuPictureBox
    Friend WithEvents BunifuButton1 As Bunifu.UI.WinForms.BunifuButton.BunifuButton
    Friend WithEvents BunifuTextBox1 As Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox
    Friend WithEvents BunifuTextBox2 As Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox
    Friend WithEvents BunifuTextBox3 As Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox
    Friend WithEvents BunifuTextBox4 As Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox
    Friend WithEvents BunifuButton2 As Bunifu.UI.WinForms.BunifuButton.BunifuButton
    Friend WithEvents lblerror As Bunifu.Framework.UI.BunifuCustomLabel
End Class
