﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.BunifuImageButton6 = New Bunifu.UI.WinForms.BunifuImageButton()
        Me.BunifuImageButton4 = New Bunifu.UI.WinForms.BunifuImageButton()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.BunifuPictureBox1 = New Bunifu.UI.WinForms.BunifuPictureBox()
        Me.BunifuImageButton2 = New Bunifu.UI.WinForms.BunifuImageButton()
        Me.BunifuFlatButton6 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton5 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton4 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton3 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton2 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton1 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.BunifuLabel16 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuLabel15 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuPictureBox8 = New Bunifu.UI.WinForms.BunifuPictureBox()
        Me.BunifuLabel14 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuLabel13 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuLabel12 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuLabel11 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuLabel10 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuLabel9 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuLabel8 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuLabel7 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuLabel6 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuLabel5 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuLabel4 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuLabel3 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuPictureBox7 = New Bunifu.UI.WinForms.BunifuPictureBox()
        Me.BunifuPictureBox6 = New Bunifu.UI.WinForms.BunifuPictureBox()
        Me.BunifuPictureBox5 = New Bunifu.UI.WinForms.BunifuPictureBox()
        Me.BunifuPictureBox4 = New Bunifu.UI.WinForms.BunifuPictureBox()
        Me.BunifuPictureBox3 = New Bunifu.UI.WinForms.BunifuPictureBox()
        Me.BunifuPictureBox2 = New Bunifu.UI.WinForms.BunifuPictureBox()
        Me.BunifuSeparator7 = New Bunifu.Framework.UI.BunifuSeparator()
        Me.BunifuSeparator6 = New Bunifu.Framework.UI.BunifuSeparator()
        Me.BunifuSeparator5 = New Bunifu.Framework.UI.BunifuSeparator()
        Me.BunifuSeparator4 = New Bunifu.Framework.UI.BunifuSeparator()
        Me.BunifuSeparator3 = New Bunifu.Framework.UI.BunifuSeparator()
        Me.BunifuSeparator2 = New Bunifu.Framework.UI.BunifuSeparator()
        Me.BunifuSeparator1 = New Bunifu.Framework.UI.BunifuSeparator()
        Me.BunifuImageButton3 = New Bunifu.UI.WinForms.BunifuImageButton()
        Me.BunifuTextBox1 = New Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox()
        Me.BunifuLabel2 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.BunifuLabel1 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuImageButton1 = New Bunifu.UI.WinForms.BunifuImageButton()
        Me.BunifuFormDock1 = New Bunifu.UI.WinForms.BunifuFormDock()
        Me.Contact11 = New PhoneBook.Contact1()
        Me.Contact21 = New PhoneBook.Contact2()
        Me.Contact31 = New PhoneBook.Contact3()
        Me.Contact41 = New PhoneBook.Contact4()
        Me.Contact51 = New PhoneBook.Contact5()
        Me.Contact61 = New PhoneBook.Contact6()
        Me.Contact71 = New PhoneBook.Contact7()
        Me.AllContacts1 = New PhoneBook.AllContacts()
        Me.AddContact1 = New PhoneBook.AddContact()
        Me.Coworkers1 = New PhoneBook.Coworkers()
        Me.Designers1 = New PhoneBook.Designers()
        Me.Developers1 = New PhoneBook.Developers()
        Me.Family1 = New PhoneBook.Family()
        Me.Panel1.SuspendLayout()
        CType(Me.BunifuPictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.BunifuPictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BunifuPictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BunifuPictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BunifuPictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BunifuPictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BunifuPictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BunifuPictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(14, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Panel1.Controls.Add(Me.BunifuImageButton6)
        Me.Panel1.Controls.Add(Me.BunifuImageButton4)
        Me.Panel1.Controls.Add(Me.Panel10)
        Me.Panel1.Controls.Add(Me.Panel9)
        Me.Panel1.Controls.Add(Me.Panel8)
        Me.Panel1.Controls.Add(Me.Panel7)
        Me.Panel1.Controls.Add(Me.Panel6)
        Me.Panel1.Controls.Add(Me.Panel5)
        Me.Panel1.Controls.Add(Me.BunifuPictureBox1)
        Me.Panel1.Controls.Add(Me.BunifuImageButton2)
        Me.Panel1.Controls.Add(Me.BunifuFlatButton6)
        Me.Panel1.Controls.Add(Me.BunifuFlatButton5)
        Me.Panel1.Controls.Add(Me.BunifuFlatButton4)
        Me.Panel1.Controls.Add(Me.BunifuFlatButton3)
        Me.Panel1.Controls.Add(Me.BunifuFlatButton2)
        Me.Panel1.Controls.Add(Me.BunifuFlatButton1)
        Me.Panel1.Location = New System.Drawing.Point(0, 38)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(205, 553)
        Me.Panel1.TabIndex = 0
        '
        'BunifuImageButton6
        '
        Me.BunifuImageButton6.ActiveImage = Nothing
        Me.BunifuImageButton6.AllowAnimations = True
        Me.BunifuImageButton6.AllowZooming = True
        Me.BunifuImageButton6.BackColor = System.Drawing.Color.Transparent
        Me.BunifuImageButton6.ErrorImage = CType(resources.GetObject("BunifuImageButton6.ErrorImage"), System.Drawing.Image)
        Me.BunifuImageButton6.FadeWhenInactive = True
        Me.BunifuImageButton6.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal
        Me.BunifuImageButton6.Image = CType(resources.GetObject("BunifuImageButton6.Image"), System.Drawing.Image)
        Me.BunifuImageButton6.ImageActive = Nothing
        Me.BunifuImageButton6.ImageLocation = Nothing
        Me.BunifuImageButton6.ImageMargin = 0
        Me.BunifuImageButton6.ImageSize = New System.Drawing.Size(17, 19)
        Me.BunifuImageButton6.ImageZoomSize = New System.Drawing.Size(17, 19)
        Me.BunifuImageButton6.InitialImage = CType(resources.GetObject("BunifuImageButton6.InitialImage"), System.Drawing.Image)
        Me.BunifuImageButton6.Location = New System.Drawing.Point(96, 496)
        Me.BunifuImageButton6.Name = "BunifuImageButton6"
        Me.BunifuImageButton6.Rotation = 0
        Me.BunifuImageButton6.ShowActiveImage = True
        Me.BunifuImageButton6.ShowCursorChanges = True
        Me.BunifuImageButton6.ShowImageBorders = False
        Me.BunifuImageButton6.ShowSizeMarkers = False
        Me.BunifuImageButton6.Size = New System.Drawing.Size(17, 19)
        Me.BunifuImageButton6.TabIndex = 40
        Me.BunifuImageButton6.ToolTipText = "Details"
        Me.BunifuImageButton6.WaitOnLoad = False
        Me.BunifuImageButton6.Zoom = 0
        Me.BunifuImageButton6.ZoomSpeed = 10
        '
        'BunifuImageButton4
        '
        Me.BunifuImageButton4.ActiveImage = Nothing
        Me.BunifuImageButton4.AllowAnimations = True
        Me.BunifuImageButton4.AllowZooming = True
        Me.BunifuImageButton4.BackColor = System.Drawing.Color.Transparent
        Me.BunifuImageButton4.ErrorImage = CType(resources.GetObject("BunifuImageButton4.ErrorImage"), System.Drawing.Image)
        Me.BunifuImageButton4.FadeWhenInactive = True
        Me.BunifuImageButton4.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal
        Me.BunifuImageButton4.Image = CType(resources.GetObject("BunifuImageButton4.Image"), System.Drawing.Image)
        Me.BunifuImageButton4.ImageActive = Nothing
        Me.BunifuImageButton4.ImageLocation = Nothing
        Me.BunifuImageButton4.ImageMargin = 0
        Me.BunifuImageButton4.ImageSize = New System.Drawing.Size(21, 19)
        Me.BunifuImageButton4.ImageZoomSize = New System.Drawing.Size(21, 19)
        Me.BunifuImageButton4.InitialImage = CType(resources.GetObject("BunifuImageButton4.InitialImage"), System.Drawing.Image)
        Me.BunifuImageButton4.Location = New System.Drawing.Point(92, 99)
        Me.BunifuImageButton4.Name = "BunifuImageButton4"
        Me.BunifuImageButton4.Rotation = 0
        Me.BunifuImageButton4.ShowActiveImage = True
        Me.BunifuImageButton4.ShowCursorChanges = True
        Me.BunifuImageButton4.ShowImageBorders = False
        Me.BunifuImageButton4.ShowSizeMarkers = False
        Me.BunifuImageButton4.Size = New System.Drawing.Size(21, 19)
        Me.BunifuImageButton4.TabIndex = 38
        Me.BunifuImageButton4.ToolTipText = "Add new"
        Me.BunifuImageButton4.WaitOnLoad = False
        Me.BunifuImageButton4.Zoom = 0
        Me.BunifuImageButton4.ZoomSpeed = 10
        '
        'Panel10
        '
        Me.Panel10.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel10.Location = New System.Drawing.Point(20, 371)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(7, 36)
        Me.Panel10.TabIndex = 37
        '
        'Panel9
        '
        Me.Panel9.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel9.Location = New System.Drawing.Point(20, 319)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(7, 36)
        Me.Panel9.TabIndex = 36
        '
        'Panel8
        '
        Me.Panel8.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel8.Location = New System.Drawing.Point(20, 268)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(7, 36)
        Me.Panel8.TabIndex = 35
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel7.Location = New System.Drawing.Point(20, 217)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(7, 36)
        Me.Panel7.TabIndex = 34
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel6.Location = New System.Drawing.Point(20, 166)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(7, 36)
        Me.Panel6.TabIndex = 33
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel5.Location = New System.Drawing.Point(20, 124)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(7, 36)
        Me.Panel5.TabIndex = 32
        '
        'BunifuPictureBox1
        '
        Me.BunifuPictureBox1.AllowFocused = False
        Me.BunifuPictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.BunifuPictureBox1.BorderRadius = 36
        Me.BunifuPictureBox1.Image = CType(resources.GetObject("BunifuPictureBox1.Image"), System.Drawing.Image)
        Me.BunifuPictureBox1.IsCircle = True
        Me.BunifuPictureBox1.Location = New System.Drawing.Point(64, 25)
        Me.BunifuPictureBox1.Name = "BunifuPictureBox1"
        Me.BunifuPictureBox1.Size = New System.Drawing.Size(73, 73)
        Me.BunifuPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.BunifuPictureBox1.TabIndex = 7
        Me.BunifuPictureBox1.TabStop = False
        Me.BunifuPictureBox1.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Square
        '
        'BunifuImageButton2
        '
        Me.BunifuImageButton2.ActiveImage = Nothing
        Me.BunifuImageButton2.AllowAnimations = True
        Me.BunifuImageButton2.AllowZooming = True
        Me.BunifuImageButton2.BackColor = System.Drawing.Color.Transparent
        Me.BunifuImageButton2.ErrorImage = CType(resources.GetObject("BunifuImageButton2.ErrorImage"), System.Drawing.Image)
        Me.BunifuImageButton2.FadeWhenInactive = True
        Me.BunifuImageButton2.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal
        Me.BunifuImageButton2.Image = CType(resources.GetObject("BunifuImageButton2.Image"), System.Drawing.Image)
        Me.BunifuImageButton2.ImageActive = Nothing
        Me.BunifuImageButton2.ImageLocation = Nothing
        Me.BunifuImageButton2.ImageMargin = 0
        Me.BunifuImageButton2.ImageSize = New System.Drawing.Size(17, 19)
        Me.BunifuImageButton2.ImageZoomSize = New System.Drawing.Size(17, 19)
        Me.BunifuImageButton2.InitialImage = CType(resources.GetObject("BunifuImageButton2.InitialImage"), System.Drawing.Image)
        Me.BunifuImageButton2.Location = New System.Drawing.Point(73, 496)
        Me.BunifuImageButton2.Name = "BunifuImageButton2"
        Me.BunifuImageButton2.Rotation = 0
        Me.BunifuImageButton2.ShowActiveImage = True
        Me.BunifuImageButton2.ShowCursorChanges = True
        Me.BunifuImageButton2.ShowImageBorders = False
        Me.BunifuImageButton2.ShowSizeMarkers = False
        Me.BunifuImageButton2.Size = New System.Drawing.Size(17, 19)
        Me.BunifuImageButton2.TabIndex = 6
        Me.BunifuImageButton2.ToolTipText = "Settings"
        Me.BunifuImageButton2.WaitOnLoad = False
        Me.BunifuImageButton2.Zoom = 0
        Me.BunifuImageButton2.ZoomSpeed = 10
        '
        'BunifuFlatButton6
        '
        Me.BunifuFlatButton6.Active = False
        Me.BunifuFlatButton6.Activecolor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(14, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.BunifuFlatButton6.BackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(14, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.BunifuFlatButton6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton6.BorderRadius = 5
        Me.BunifuFlatButton6.ButtonText = "Family"
        Me.BunifuFlatButton6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuFlatButton6.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton6.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton6.Iconimage = CType(resources.GetObject("BunifuFlatButton6.Iconimage"), System.Drawing.Image)
        Me.BunifuFlatButton6.Iconimage_right = Nothing
        Me.BunifuFlatButton6.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton6.Iconimage_Selected = Nothing
        Me.BunifuFlatButton6.IconMarginLeft = 0
        Me.BunifuFlatButton6.IconMarginRight = 0
        Me.BunifuFlatButton6.IconRightVisible = True
        Me.BunifuFlatButton6.IconRightZoom = 0R
        Me.BunifuFlatButton6.IconVisible = True
        Me.BunifuFlatButton6.IconZoom = 50.0R
        Me.BunifuFlatButton6.IsTab = False
        Me.BunifuFlatButton6.Location = New System.Drawing.Point(33, 371)
        Me.BunifuFlatButton6.Name = "BunifuFlatButton6"
        Me.BunifuFlatButton6.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(14, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.BunifuFlatButton6.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(3, Byte), Integer), CType(CType(11, Byte), Integer), CType(CType(65, Byte), Integer))
        Me.BunifuFlatButton6.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton6.selected = False
        Me.BunifuFlatButton6.Size = New System.Drawing.Size(163, 36)
        Me.BunifuFlatButton6.TabIndex = 5
        Me.BunifuFlatButton6.Text = "Family"
        Me.BunifuFlatButton6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BunifuFlatButton6.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton6.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton5
        '
        Me.BunifuFlatButton5.Active = False
        Me.BunifuFlatButton5.Activecolor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(14, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.BunifuFlatButton5.BackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(14, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.BunifuFlatButton5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton5.BorderRadius = 5
        Me.BunifuFlatButton5.ButtonText = "Developers"
        Me.BunifuFlatButton5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuFlatButton5.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton5.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton5.Iconimage = CType(resources.GetObject("BunifuFlatButton5.Iconimage"), System.Drawing.Image)
        Me.BunifuFlatButton5.Iconimage_right = Nothing
        Me.BunifuFlatButton5.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton5.Iconimage_Selected = Nothing
        Me.BunifuFlatButton5.IconMarginLeft = 0
        Me.BunifuFlatButton5.IconMarginRight = 0
        Me.BunifuFlatButton5.IconRightVisible = True
        Me.BunifuFlatButton5.IconRightZoom = 0R
        Me.BunifuFlatButton5.IconVisible = True
        Me.BunifuFlatButton5.IconZoom = 50.0R
        Me.BunifuFlatButton5.IsTab = False
        Me.BunifuFlatButton5.Location = New System.Drawing.Point(33, 319)
        Me.BunifuFlatButton5.Name = "BunifuFlatButton5"
        Me.BunifuFlatButton5.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(14, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.BunifuFlatButton5.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(3, Byte), Integer), CType(CType(11, Byte), Integer), CType(CType(65, Byte), Integer))
        Me.BunifuFlatButton5.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton5.selected = False
        Me.BunifuFlatButton5.Size = New System.Drawing.Size(163, 36)
        Me.BunifuFlatButton5.TabIndex = 4
        Me.BunifuFlatButton5.Text = "Developers"
        Me.BunifuFlatButton5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BunifuFlatButton5.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton5.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton4
        '
        Me.BunifuFlatButton4.Active = False
        Me.BunifuFlatButton4.Activecolor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(14, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.BunifuFlatButton4.BackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(14, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.BunifuFlatButton4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton4.BorderRadius = 5
        Me.BunifuFlatButton4.ButtonText = "Designers"
        Me.BunifuFlatButton4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuFlatButton4.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton4.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton4.Iconimage = CType(resources.GetObject("BunifuFlatButton4.Iconimage"), System.Drawing.Image)
        Me.BunifuFlatButton4.Iconimage_right = Nothing
        Me.BunifuFlatButton4.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton4.Iconimage_Selected = Nothing
        Me.BunifuFlatButton4.IconMarginLeft = 0
        Me.BunifuFlatButton4.IconMarginRight = 0
        Me.BunifuFlatButton4.IconRightVisible = True
        Me.BunifuFlatButton4.IconRightZoom = 0R
        Me.BunifuFlatButton4.IconVisible = True
        Me.BunifuFlatButton4.IconZoom = 50.0R
        Me.BunifuFlatButton4.IsTab = False
        Me.BunifuFlatButton4.Location = New System.Drawing.Point(33, 268)
        Me.BunifuFlatButton4.Name = "BunifuFlatButton4"
        Me.BunifuFlatButton4.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(14, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.BunifuFlatButton4.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(3, Byte), Integer), CType(CType(11, Byte), Integer), CType(CType(65, Byte), Integer))
        Me.BunifuFlatButton4.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton4.selected = False
        Me.BunifuFlatButton4.Size = New System.Drawing.Size(163, 36)
        Me.BunifuFlatButton4.TabIndex = 3
        Me.BunifuFlatButton4.Text = "Designers"
        Me.BunifuFlatButton4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BunifuFlatButton4.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton4.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton3
        '
        Me.BunifuFlatButton3.Active = False
        Me.BunifuFlatButton3.Activecolor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(14, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.BunifuFlatButton3.BackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(14, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.BunifuFlatButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton3.BorderRadius = 5
        Me.BunifuFlatButton3.ButtonText = "Co-Workers"
        Me.BunifuFlatButton3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuFlatButton3.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton3.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton3.Iconimage = CType(resources.GetObject("BunifuFlatButton3.Iconimage"), System.Drawing.Image)
        Me.BunifuFlatButton3.Iconimage_right = Nothing
        Me.BunifuFlatButton3.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton3.Iconimage_Selected = Nothing
        Me.BunifuFlatButton3.IconMarginLeft = 0
        Me.BunifuFlatButton3.IconMarginRight = 0
        Me.BunifuFlatButton3.IconRightVisible = True
        Me.BunifuFlatButton3.IconRightZoom = 0R
        Me.BunifuFlatButton3.IconVisible = True
        Me.BunifuFlatButton3.IconZoom = 50.0R
        Me.BunifuFlatButton3.IsTab = False
        Me.BunifuFlatButton3.Location = New System.Drawing.Point(33, 217)
        Me.BunifuFlatButton3.Name = "BunifuFlatButton3"
        Me.BunifuFlatButton3.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(14, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.BunifuFlatButton3.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(3, Byte), Integer), CType(CType(11, Byte), Integer), CType(CType(65, Byte), Integer))
        Me.BunifuFlatButton3.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton3.selected = False
        Me.BunifuFlatButton3.Size = New System.Drawing.Size(163, 36)
        Me.BunifuFlatButton3.TabIndex = 2
        Me.BunifuFlatButton3.Text = "Co-Workers"
        Me.BunifuFlatButton3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BunifuFlatButton3.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton3.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton2
        '
        Me.BunifuFlatButton2.Active = False
        Me.BunifuFlatButton2.Activecolor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(14, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.BunifuFlatButton2.BackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(14, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.BunifuFlatButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton2.BorderRadius = 5
        Me.BunifuFlatButton2.ButtonText = "Friends"
        Me.BunifuFlatButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuFlatButton2.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton2.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton2.Iconimage = CType(resources.GetObject("BunifuFlatButton2.Iconimage"), System.Drawing.Image)
        Me.BunifuFlatButton2.Iconimage_right = Nothing
        Me.BunifuFlatButton2.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton2.Iconimage_Selected = Nothing
        Me.BunifuFlatButton2.IconMarginLeft = 0
        Me.BunifuFlatButton2.IconMarginRight = 0
        Me.BunifuFlatButton2.IconRightVisible = True
        Me.BunifuFlatButton2.IconRightZoom = 0R
        Me.BunifuFlatButton2.IconVisible = True
        Me.BunifuFlatButton2.IconZoom = 50.0R
        Me.BunifuFlatButton2.IsTab = False
        Me.BunifuFlatButton2.Location = New System.Drawing.Point(33, 166)
        Me.BunifuFlatButton2.Name = "BunifuFlatButton2"
        Me.BunifuFlatButton2.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(14, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.BunifuFlatButton2.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(3, Byte), Integer), CType(CType(11, Byte), Integer), CType(CType(65, Byte), Integer))
        Me.BunifuFlatButton2.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton2.selected = False
        Me.BunifuFlatButton2.Size = New System.Drawing.Size(163, 36)
        Me.BunifuFlatButton2.TabIndex = 1
        Me.BunifuFlatButton2.Text = "Friends"
        Me.BunifuFlatButton2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BunifuFlatButton2.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton2.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton1
        '
        Me.BunifuFlatButton1.Active = True
        Me.BunifuFlatButton1.Activecolor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(14, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.BunifuFlatButton1.BackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(14, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.BunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton1.BorderRadius = 5
        Me.BunifuFlatButton1.ButtonText = "All Contacts"
        Me.BunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton1.Iconimage = CType(resources.GetObject("BunifuFlatButton1.Iconimage"), System.Drawing.Image)
        Me.BunifuFlatButton1.Iconimage_right = Nothing
        Me.BunifuFlatButton1.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton1.Iconimage_Selected = Nothing
        Me.BunifuFlatButton1.IconMarginLeft = 0
        Me.BunifuFlatButton1.IconMarginRight = 0
        Me.BunifuFlatButton1.IconRightVisible = True
        Me.BunifuFlatButton1.IconRightZoom = 0R
        Me.BunifuFlatButton1.IconVisible = True
        Me.BunifuFlatButton1.IconZoom = 50.0R
        Me.BunifuFlatButton1.IsTab = False
        Me.BunifuFlatButton1.Location = New System.Drawing.Point(33, 124)
        Me.BunifuFlatButton1.Name = "BunifuFlatButton1"
        Me.BunifuFlatButton1.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(14, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.BunifuFlatButton1.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(3, Byte), Integer), CType(CType(11, Byte), Integer), CType(CType(65, Byte), Integer))
        Me.BunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton1.selected = True
        Me.BunifuFlatButton1.Size = New System.Drawing.Size(163, 36)
        Me.BunifuFlatButton1.TabIndex = 0
        Me.BunifuFlatButton1.Text = "All Contacts"
        Me.BunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BunifuFlatButton1.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton1.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Panel3.Controls.Add(Me.AllContacts1)
        Me.Panel3.Controls.Add(Me.AddContact1)
        Me.Panel3.Controls.Add(Me.Coworkers1)
        Me.Panel3.Controls.Add(Me.Designers1)
        Me.Panel3.Controls.Add(Me.Developers1)
        Me.Panel3.Controls.Add(Me.Family1)
        Me.Panel3.Controls.Add(Me.BunifuLabel16)
        Me.Panel3.Controls.Add(Me.BunifuLabel15)
        Me.Panel3.Controls.Add(Me.BunifuPictureBox8)
        Me.Panel3.Controls.Add(Me.BunifuLabel14)
        Me.Panel3.Controls.Add(Me.BunifuLabel13)
        Me.Panel3.Controls.Add(Me.BunifuLabel12)
        Me.Panel3.Controls.Add(Me.BunifuLabel11)
        Me.Panel3.Controls.Add(Me.BunifuLabel10)
        Me.Panel3.Controls.Add(Me.BunifuLabel9)
        Me.Panel3.Controls.Add(Me.BunifuLabel8)
        Me.Panel3.Controls.Add(Me.BunifuLabel7)
        Me.Panel3.Controls.Add(Me.BunifuLabel6)
        Me.Panel3.Controls.Add(Me.BunifuLabel5)
        Me.Panel3.Controls.Add(Me.BunifuLabel4)
        Me.Panel3.Controls.Add(Me.BunifuLabel3)
        Me.Panel3.Controls.Add(Me.BunifuPictureBox7)
        Me.Panel3.Controls.Add(Me.BunifuPictureBox6)
        Me.Panel3.Controls.Add(Me.BunifuPictureBox5)
        Me.Panel3.Controls.Add(Me.BunifuPictureBox4)
        Me.Panel3.Controls.Add(Me.BunifuPictureBox3)
        Me.Panel3.Controls.Add(Me.BunifuPictureBox2)
        Me.Panel3.Controls.Add(Me.BunifuSeparator7)
        Me.Panel3.Controls.Add(Me.BunifuSeparator6)
        Me.Panel3.Controls.Add(Me.BunifuSeparator5)
        Me.Panel3.Controls.Add(Me.BunifuSeparator4)
        Me.Panel3.Controls.Add(Me.BunifuSeparator3)
        Me.Panel3.Controls.Add(Me.BunifuSeparator2)
        Me.Panel3.Controls.Add(Me.BunifuSeparator1)
        Me.Panel3.Controls.Add(Me.BunifuImageButton3)
        Me.Panel3.Controls.Add(Me.BunifuTextBox1)
        Me.Panel3.Controls.Add(Me.BunifuLabel2)
        Me.Panel3.Location = New System.Drawing.Point(214, 38)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(546, 553)
        Me.Panel3.TabIndex = 2
        '
        'BunifuLabel16
        '
        Me.BunifuLabel16.AutoEllipsis = False
        Me.BunifuLabel16.CursorType = Nothing
        Me.BunifuLabel16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel16.ForeColor = System.Drawing.Color.Gray
        Me.BunifuLabel16.Location = New System.Drawing.Point(366, 462)
        Me.BunifuLabel16.Name = "BunifuLabel16"
        Me.BunifuLabel16.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel16.Size = New System.Drawing.Size(103, 18)
        Me.BunifuLabel16.TabIndex = 30
        Me.BunifuLabel16.Text = "+49 176 456 4587"
        Me.BunifuLabel16.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        '
        'BunifuLabel15
        '
        Me.BunifuLabel15.AutoEllipsis = False
        Me.BunifuLabel15.CursorType = Nothing
        Me.BunifuLabel15.Font = New System.Drawing.Font("Montserrat ExtraBold", 9.749999!, System.Drawing.FontStyle.Bold)
        Me.BunifuLabel15.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.BunifuLabel15.Location = New System.Drawing.Point(112, 452)
        Me.BunifuLabel15.Name = "BunifuLabel15"
        Me.BunifuLabel15.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel15.Size = New System.Drawing.Size(127, 37)
        Me.BunifuLabel15.TabIndex = 29
        Me.BunifuLabel15.Text = "Lisa H. Hagler" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "<span style=""color:gray;font-size:8pt;font-family:georgia;""><i>Fr" &
    "ankfurt,Germany</i></span>"
        Me.BunifuLabel15.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        '
        'BunifuPictureBox8
        '
        Me.BunifuPictureBox8.AllowFocused = False
        Me.BunifuPictureBox8.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.BunifuPictureBox8.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.BunifuPictureBox8.BorderRadius = 24
        Me.BunifuPictureBox8.Image = CType(resources.GetObject("BunifuPictureBox8.Image"), System.Drawing.Image)
        Me.BunifuPictureBox8.IsCircle = True
        Me.BunifuPictureBox8.Location = New System.Drawing.Point(46, 441)
        Me.BunifuPictureBox8.Name = "BunifuPictureBox8"
        Me.BunifuPictureBox8.Size = New System.Drawing.Size(48, 48)
        Me.BunifuPictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.BunifuPictureBox8.TabIndex = 28
        Me.BunifuPictureBox8.TabStop = False
        Me.BunifuPictureBox8.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Square
        '
        'BunifuLabel14
        '
        Me.BunifuLabel14.AutoEllipsis = False
        Me.BunifuLabel14.CursorType = Nothing
        Me.BunifuLabel14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel14.ForeColor = System.Drawing.Color.Gray
        Me.BunifuLabel14.Location = New System.Drawing.Point(366, 406)
        Me.BunifuLabel14.Name = "BunifuLabel14"
        Me.BunifuLabel14.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel14.Size = New System.Drawing.Size(103, 18)
        Me.BunifuLabel14.TabIndex = 27
        Me.BunifuLabel14.Text = "+49 176 308 4587"
        Me.BunifuLabel14.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        '
        'BunifuLabel13
        '
        Me.BunifuLabel13.AutoEllipsis = False
        Me.BunifuLabel13.CursorType = Nothing
        Me.BunifuLabel13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel13.ForeColor = System.Drawing.Color.Gray
        Me.BunifuLabel13.Location = New System.Drawing.Point(366, 349)
        Me.BunifuLabel13.Name = "BunifuLabel13"
        Me.BunifuLabel13.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel13.Size = New System.Drawing.Size(103, 18)
        Me.BunifuLabel13.TabIndex = 26
        Me.BunifuLabel13.Text = "+49 176 458 5587"
        Me.BunifuLabel13.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        '
        'BunifuLabel12
        '
        Me.BunifuLabel12.AutoEllipsis = False
        Me.BunifuLabel12.CursorType = Nothing
        Me.BunifuLabel12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel12.ForeColor = System.Drawing.Color.Gray
        Me.BunifuLabel12.Location = New System.Drawing.Point(366, 286)
        Me.BunifuLabel12.Name = "BunifuLabel12"
        Me.BunifuLabel12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel12.Size = New System.Drawing.Size(96, 18)
        Me.BunifuLabel12.TabIndex = 25
        Me.BunifuLabel12.Text = "+1 176 358 4587"
        Me.BunifuLabel12.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        '
        'BunifuLabel11
        '
        Me.BunifuLabel11.AutoEllipsis = False
        Me.BunifuLabel11.CursorType = Nothing
        Me.BunifuLabel11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel11.ForeColor = System.Drawing.Color.Gray
        Me.BunifuLabel11.Location = New System.Drawing.Point(366, 217)
        Me.BunifuLabel11.Name = "BunifuLabel11"
        Me.BunifuLabel11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel11.Size = New System.Drawing.Size(103, 18)
        Me.BunifuLabel11.TabIndex = 24
        Me.BunifuLabel11.Text = "+56 176 458 4587"
        Me.BunifuLabel11.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        '
        'BunifuLabel10
        '
        Me.BunifuLabel10.AutoEllipsis = False
        Me.BunifuLabel10.CursorType = Nothing
        Me.BunifuLabel10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel10.ForeColor = System.Drawing.Color.Gray
        Me.BunifuLabel10.Location = New System.Drawing.Point(366, 142)
        Me.BunifuLabel10.Name = "BunifuLabel10"
        Me.BunifuLabel10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel10.Size = New System.Drawing.Size(96, 18)
        Me.BunifuLabel10.TabIndex = 23
        Me.BunifuLabel10.Text = "+1 176 458 4587"
        Me.BunifuLabel10.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        '
        'BunifuLabel9
        '
        Me.BunifuLabel9.AutoEllipsis = False
        Me.BunifuLabel9.CursorType = Nothing
        Me.BunifuLabel9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel9.ForeColor = System.Drawing.Color.Gray
        Me.BunifuLabel9.Location = New System.Drawing.Point(366, 89)
        Me.BunifuLabel9.Name = "BunifuLabel9"
        Me.BunifuLabel9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel9.Size = New System.Drawing.Size(103, 18)
        Me.BunifuLabel9.TabIndex = 22
        Me.BunifuLabel9.Text = "+49 176 458 4587"
        Me.BunifuLabel9.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        '
        'BunifuLabel8
        '
        Me.BunifuLabel8.AutoEllipsis = False
        Me.BunifuLabel8.CursorType = Nothing
        Me.BunifuLabel8.Font = New System.Drawing.Font("Montserrat ExtraBold", 9.749999!, System.Drawing.FontStyle.Bold)
        Me.BunifuLabel8.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.BunifuLabel8.Location = New System.Drawing.Point(112, 387)
        Me.BunifuLabel8.Name = "BunifuLabel8"
        Me.BunifuLabel8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel8.Size = New System.Drawing.Size(127, 37)
        Me.BunifuLabel8.TabIndex = 21
        Me.BunifuLabel8.Text = "Hank M. Zakroff" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "<span style=""color:gray;font-size:8pt;font-family:georgia;""><i>F" &
    "rankfurt,Germany</i></span>"
        Me.BunifuLabel8.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        '
        'BunifuLabel7
        '
        Me.BunifuLabel7.AutoEllipsis = False
        Me.BunifuLabel7.CursorType = Nothing
        Me.BunifuLabel7.Font = New System.Drawing.Font("Montserrat ExtraBold", 9.749999!, System.Drawing.FontStyle.Bold)
        Me.BunifuLabel7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.BunifuLabel7.Location = New System.Drawing.Point(112, 330)
        Me.BunifuLabel7.Name = "BunifuLabel7"
        Me.BunifuLabel7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel7.Size = New System.Drawing.Size(127, 37)
        Me.BunifuLabel7.TabIndex = 20
        Me.BunifuLabel7.Text = "David Taylor" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "<span style=""color:gray;font-size:8pt;font-family:georgia;""><i>Fran" &
    "kfurt,Germany</i></span>"
        Me.BunifuLabel7.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        '
        'BunifuLabel6
        '
        Me.BunifuLabel6.AutoEllipsis = False
        Me.BunifuLabel6.CursorType = Nothing
        Me.BunifuLabel6.Font = New System.Drawing.Font("Montserrat ExtraBold", 9.749999!, System.Drawing.FontStyle.Bold)
        Me.BunifuLabel6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.BunifuLabel6.Location = New System.Drawing.Point(112, 267)
        Me.BunifuLabel6.Name = "BunifuLabel6"
        Me.BunifuLabel6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel6.Size = New System.Drawing.Size(180, 37)
        Me.BunifuLabel6.TabIndex = 19
        Me.BunifuLabel6.Text = "Kerem Suer" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "<span style=""color:gray;font-size:8pt;font-family:georgia;""><i>San Fr" &
    "ancisco, United States</i></span>"
        Me.BunifuLabel6.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        '
        'BunifuLabel5
        '
        Me.BunifuLabel5.AutoEllipsis = False
        Me.BunifuLabel5.CursorType = Nothing
        Me.BunifuLabel5.Font = New System.Drawing.Font("Montserrat ExtraBold", 9.749999!, System.Drawing.FontStyle.Bold)
        Me.BunifuLabel5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.BunifuLabel5.Location = New System.Drawing.Point(112, 201)
        Me.BunifuLabel5.Name = "BunifuLabel5"
        Me.BunifuLabel5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel5.Size = New System.Drawing.Size(110, 37)
        Me.BunifuLabel5.TabIndex = 18
        Me.BunifuLabel5.Text = "Kate Bell" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "<span style=""color:gray;font-size:8pt;font-family:georgia;""><i>London," &
    " England</i></span>"
        Me.BunifuLabel5.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        '
        'BunifuLabel4
        '
        Me.BunifuLabel4.AutoEllipsis = False
        Me.BunifuLabel4.CursorType = Nothing
        Me.BunifuLabel4.Font = New System.Drawing.Font("Montserrat ExtraBold", 9.749999!, System.Drawing.FontStyle.Bold)
        Me.BunifuLabel4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.BunifuLabel4.Location = New System.Drawing.Point(112, 135)
        Me.BunifuLabel4.Name = "BunifuLabel4"
        Me.BunifuLabel4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel4.Size = New System.Drawing.Size(154, 37)
        Me.BunifuLabel4.TabIndex = 17
        Me.BunifuLabel4.Text = "John Appleseed" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "<span style=""color:gray;font-size:8pt;font-family:georgia;""><i>Ne" &
    "w York, United States</i></span>"
        Me.BunifuLabel4.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        '
        'BunifuLabel3
        '
        Me.BunifuLabel3.AutoEllipsis = False
        Me.BunifuLabel3.CursorType = Nothing
        Me.BunifuLabel3.Font = New System.Drawing.Font("Montserrat ExtraBold", 9.749999!, System.Drawing.FontStyle.Bold)
        Me.BunifuLabel3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.BunifuLabel3.Location = New System.Drawing.Point(112, 70)
        Me.BunifuLabel3.Name = "BunifuLabel3"
        Me.BunifuLabel3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel3.Size = New System.Drawing.Size(127, 37)
        Me.BunifuLabel3.TabIndex = 16
        Me.BunifuLabel3.Text = "Anna Haro" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "<span style=""color:gray;font-size:8pt;font-family:georgia;""><i>Frankfu" &
    "rt,Germany</i></span>"
        Me.BunifuLabel3.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        '
        'BunifuPictureBox7
        '
        Me.BunifuPictureBox7.AllowFocused = False
        Me.BunifuPictureBox7.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.BunifuPictureBox7.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.BunifuPictureBox7.BorderRadius = 24
        Me.BunifuPictureBox7.Image = CType(resources.GetObject("BunifuPictureBox7.Image"), System.Drawing.Image)
        Me.BunifuPictureBox7.IsCircle = True
        Me.BunifuPictureBox7.Location = New System.Drawing.Point(46, 387)
        Me.BunifuPictureBox7.Name = "BunifuPictureBox7"
        Me.BunifuPictureBox7.Size = New System.Drawing.Size(48, 48)
        Me.BunifuPictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.BunifuPictureBox7.TabIndex = 15
        Me.BunifuPictureBox7.TabStop = False
        Me.BunifuPictureBox7.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Square
        '
        'BunifuPictureBox6
        '
        Me.BunifuPictureBox6.AllowFocused = False
        Me.BunifuPictureBox6.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.BunifuPictureBox6.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.BunifuPictureBox6.BorderRadius = 24
        Me.BunifuPictureBox6.Image = CType(resources.GetObject("BunifuPictureBox6.Image"), System.Drawing.Image)
        Me.BunifuPictureBox6.IsCircle = True
        Me.BunifuPictureBox6.Location = New System.Drawing.Point(46, 319)
        Me.BunifuPictureBox6.Name = "BunifuPictureBox6"
        Me.BunifuPictureBox6.Size = New System.Drawing.Size(48, 48)
        Me.BunifuPictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.BunifuPictureBox6.TabIndex = 14
        Me.BunifuPictureBox6.TabStop = False
        Me.BunifuPictureBox6.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Square
        '
        'BunifuPictureBox5
        '
        Me.BunifuPictureBox5.AllowFocused = False
        Me.BunifuPictureBox5.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.BunifuPictureBox5.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.BunifuPictureBox5.BorderRadius = 24
        Me.BunifuPictureBox5.Image = CType(resources.GetObject("BunifuPictureBox5.Image"), System.Drawing.Image)
        Me.BunifuPictureBox5.IsCircle = True
        Me.BunifuPictureBox5.Location = New System.Drawing.Point(46, 256)
        Me.BunifuPictureBox5.Name = "BunifuPictureBox5"
        Me.BunifuPictureBox5.Size = New System.Drawing.Size(48, 48)
        Me.BunifuPictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.BunifuPictureBox5.TabIndex = 13
        Me.BunifuPictureBox5.TabStop = False
        Me.BunifuPictureBox5.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Square
        '
        'BunifuPictureBox4
        '
        Me.BunifuPictureBox4.AllowFocused = False
        Me.BunifuPictureBox4.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.BunifuPictureBox4.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.BunifuPictureBox4.BorderRadius = 24
        Me.BunifuPictureBox4.Image = CType(resources.GetObject("BunifuPictureBox4.Image"), System.Drawing.Image)
        Me.BunifuPictureBox4.IsCircle = True
        Me.BunifuPictureBox4.Location = New System.Drawing.Point(46, 190)
        Me.BunifuPictureBox4.Name = "BunifuPictureBox4"
        Me.BunifuPictureBox4.Size = New System.Drawing.Size(48, 48)
        Me.BunifuPictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.BunifuPictureBox4.TabIndex = 12
        Me.BunifuPictureBox4.TabStop = False
        Me.BunifuPictureBox4.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Square
        '
        'BunifuPictureBox3
        '
        Me.BunifuPictureBox3.AllowFocused = False
        Me.BunifuPictureBox3.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.BunifuPictureBox3.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.BunifuPictureBox3.BorderRadius = 24
        Me.BunifuPictureBox3.Image = CType(resources.GetObject("BunifuPictureBox3.Image"), System.Drawing.Image)
        Me.BunifuPictureBox3.IsCircle = True
        Me.BunifuPictureBox3.Location = New System.Drawing.Point(46, 124)
        Me.BunifuPictureBox3.Name = "BunifuPictureBox3"
        Me.BunifuPictureBox3.Size = New System.Drawing.Size(48, 48)
        Me.BunifuPictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.BunifuPictureBox3.TabIndex = 11
        Me.BunifuPictureBox3.TabStop = False
        Me.BunifuPictureBox3.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Square
        '
        'BunifuPictureBox2
        '
        Me.BunifuPictureBox2.AllowFocused = False
        Me.BunifuPictureBox2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.BunifuPictureBox2.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.BunifuPictureBox2.BorderRadius = 24
        Me.BunifuPictureBox2.Image = CType(resources.GetObject("BunifuPictureBox2.Image"), System.Drawing.Image)
        Me.BunifuPictureBox2.IsCircle = True
        Me.BunifuPictureBox2.Location = New System.Drawing.Point(46, 59)
        Me.BunifuPictureBox2.Name = "BunifuPictureBox2"
        Me.BunifuPictureBox2.Size = New System.Drawing.Size(48, 48)
        Me.BunifuPictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.BunifuPictureBox2.TabIndex = 10
        Me.BunifuPictureBox2.TabStop = False
        Me.BunifuPictureBox2.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Square
        '
        'BunifuSeparator7
        '
        Me.BunifuSeparator7.BackColor = System.Drawing.Color.Transparent
        Me.BunifuSeparator7.LineColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer))
        Me.BunifuSeparator7.LineThickness = 1
        Me.BunifuSeparator7.Location = New System.Drawing.Point(25, 480)
        Me.BunifuSeparator7.Name = "BunifuSeparator7"
        Me.BunifuSeparator7.Size = New System.Drawing.Size(499, 35)
        Me.BunifuSeparator7.TabIndex = 9
        Me.BunifuSeparator7.Transparency = 255
        Me.BunifuSeparator7.Vertical = False
        '
        'BunifuSeparator6
        '
        Me.BunifuSeparator6.BackColor = System.Drawing.Color.Transparent
        Me.BunifuSeparator6.LineColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer))
        Me.BunifuSeparator6.LineThickness = 1
        Me.BunifuSeparator6.Location = New System.Drawing.Point(25, 421)
        Me.BunifuSeparator6.Name = "BunifuSeparator6"
        Me.BunifuSeparator6.Size = New System.Drawing.Size(499, 35)
        Me.BunifuSeparator6.TabIndex = 8
        Me.BunifuSeparator6.Transparency = 255
        Me.BunifuSeparator6.Vertical = False
        '
        'BunifuSeparator5
        '
        Me.BunifuSeparator5.BackColor = System.Drawing.Color.Transparent
        Me.BunifuSeparator5.LineColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer))
        Me.BunifuSeparator5.LineThickness = 1
        Me.BunifuSeparator5.Location = New System.Drawing.Point(25, 357)
        Me.BunifuSeparator5.Name = "BunifuSeparator5"
        Me.BunifuSeparator5.Size = New System.Drawing.Size(499, 35)
        Me.BunifuSeparator5.TabIndex = 7
        Me.BunifuSeparator5.Transparency = 255
        Me.BunifuSeparator5.Vertical = False
        '
        'BunifuSeparator4
        '
        Me.BunifuSeparator4.BackColor = System.Drawing.Color.Transparent
        Me.BunifuSeparator4.LineColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer))
        Me.BunifuSeparator4.LineThickness = 1
        Me.BunifuSeparator4.Location = New System.Drawing.Point(25, 301)
        Me.BunifuSeparator4.Name = "BunifuSeparator4"
        Me.BunifuSeparator4.Size = New System.Drawing.Size(499, 35)
        Me.BunifuSeparator4.TabIndex = 6
        Me.BunifuSeparator4.Transparency = 255
        Me.BunifuSeparator4.Vertical = False
        '
        'BunifuSeparator3
        '
        Me.BunifuSeparator3.BackColor = System.Drawing.Color.Transparent
        Me.BunifuSeparator3.LineColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer))
        Me.BunifuSeparator3.LineThickness = 1
        Me.BunifuSeparator3.Location = New System.Drawing.Point(25, 230)
        Me.BunifuSeparator3.Name = "BunifuSeparator3"
        Me.BunifuSeparator3.Size = New System.Drawing.Size(499, 35)
        Me.BunifuSeparator3.TabIndex = 5
        Me.BunifuSeparator3.Transparency = 255
        Me.BunifuSeparator3.Vertical = False
        '
        'BunifuSeparator2
        '
        Me.BunifuSeparator2.BackColor = System.Drawing.Color.Transparent
        Me.BunifuSeparator2.LineColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer))
        Me.BunifuSeparator2.LineThickness = 1
        Me.BunifuSeparator2.Location = New System.Drawing.Point(25, 166)
        Me.BunifuSeparator2.Name = "BunifuSeparator2"
        Me.BunifuSeparator2.Size = New System.Drawing.Size(499, 35)
        Me.BunifuSeparator2.TabIndex = 4
        Me.BunifuSeparator2.Transparency = 255
        Me.BunifuSeparator2.Vertical = False
        '
        'BunifuSeparator1
        '
        Me.BunifuSeparator1.BackColor = System.Drawing.Color.Transparent
        Me.BunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer))
        Me.BunifuSeparator1.LineThickness = 1
        Me.BunifuSeparator1.Location = New System.Drawing.Point(25, 99)
        Me.BunifuSeparator1.Name = "BunifuSeparator1"
        Me.BunifuSeparator1.Size = New System.Drawing.Size(499, 35)
        Me.BunifuSeparator1.TabIndex = 3
        Me.BunifuSeparator1.Transparency = 255
        Me.BunifuSeparator1.Vertical = False
        '
        'BunifuImageButton3
        '
        Me.BunifuImageButton3.ActiveImage = Nothing
        Me.BunifuImageButton3.AllowAnimations = True
        Me.BunifuImageButton3.AllowZooming = True
        Me.BunifuImageButton3.BackColor = System.Drawing.Color.Transparent
        Me.BunifuImageButton3.ErrorImage = CType(resources.GetObject("BunifuImageButton3.ErrorImage"), System.Drawing.Image)
        Me.BunifuImageButton3.FadeWhenInactive = True
        Me.BunifuImageButton3.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal
        Me.BunifuImageButton3.Image = CType(resources.GetObject("BunifuImageButton3.Image"), System.Drawing.Image)
        Me.BunifuImageButton3.ImageActive = Nothing
        Me.BunifuImageButton3.ImageLocation = Nothing
        Me.BunifuImageButton3.ImageMargin = 0
        Me.BunifuImageButton3.ImageSize = New System.Drawing.Size(29, 31)
        Me.BunifuImageButton3.ImageZoomSize = New System.Drawing.Size(29, 31)
        Me.BunifuImageButton3.InitialImage = CType(resources.GetObject("BunifuImageButton3.InitialImage"), System.Drawing.Image)
        Me.BunifuImageButton3.Location = New System.Drawing.Point(469, 9)
        Me.BunifuImageButton3.Name = "BunifuImageButton3"
        Me.BunifuImageButton3.Rotation = 0
        Me.BunifuImageButton3.ShowActiveImage = True
        Me.BunifuImageButton3.ShowCursorChanges = True
        Me.BunifuImageButton3.ShowImageBorders = False
        Me.BunifuImageButton3.ShowSizeMarkers = False
        Me.BunifuImageButton3.Size = New System.Drawing.Size(29, 31)
        Me.BunifuImageButton3.TabIndex = 2
        Me.BunifuImageButton3.ToolTipText = ""
        Me.BunifuImageButton3.WaitOnLoad = False
        Me.BunifuImageButton3.Zoom = 0
        Me.BunifuImageButton3.ZoomSpeed = 10
        '
        'BunifuTextBox1
        '
        Me.BunifuTextBox1.AcceptsReturn = False
        Me.BunifuTextBox1.AcceptsTab = False
        Me.BunifuTextBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.BunifuTextBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.BunifuTextBox1.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTextBox1.BackgroundImage = CType(resources.GetObject("BunifuTextBox1.BackgroundImage"), System.Drawing.Image)
        Me.BunifuTextBox1.BorderColorActive = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.BunifuTextBox1.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(161, Byte), Integer))
        Me.BunifuTextBox1.BorderColorHover = System.Drawing.Color.Teal
        Me.BunifuTextBox1.BorderColorIdle = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(107, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.BunifuTextBox1.BorderRadius = 25
        Me.BunifuTextBox1.BorderThickness = 1
        Me.BunifuTextBox1.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.BunifuTextBox1.DefaultFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuTextBox1.DefaultText = ""
        Me.BunifuTextBox1.FillColor = System.Drawing.Color.White
        Me.BunifuTextBox1.HideSelection = True
        Me.BunifuTextBox1.IconLeft = Nothing
        Me.BunifuTextBox1.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.BunifuTextBox1.IconPadding = 10
        Me.BunifuTextBox1.IconRight = CType(resources.GetObject("BunifuTextBox1.IconRight"), System.Drawing.Image)
        Me.BunifuTextBox1.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.BunifuTextBox1.Location = New System.Drawing.Point(147, 25)
        Me.BunifuTextBox1.MaxLength = 32767
        Me.BunifuTextBox1.MinimumSize = New System.Drawing.Size(80, 20)
        Me.BunifuTextBox1.Modified = False
        Me.BunifuTextBox1.Name = "BunifuTextBox1"
        Me.BunifuTextBox1.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.BunifuTextBox1.ReadOnly = False
        Me.BunifuTextBox1.SelectedText = ""
        Me.BunifuTextBox1.SelectionLength = 0
        Me.BunifuTextBox1.SelectionStart = 0
        Me.BunifuTextBox1.ShortcutsEnabled = True
        Me.BunifuTextBox1.Size = New System.Drawing.Size(208, 28)
        Me.BunifuTextBox1.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu
        Me.BunifuTextBox1.TabIndex = 1
        Me.BunifuTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.BunifuTextBox1.TextMarginLeft = 5
        Me.BunifuTextBox1.TextPlaceholder = "Search"
        Me.BunifuTextBox1.UseSystemPasswordChar = False
        '
        'BunifuLabel2
        '
        Me.BunifuLabel2.AutoEllipsis = False
        Me.BunifuLabel2.CursorType = Nothing
        Me.BunifuLabel2.Font = New System.Drawing.Font("Yu Gothic UI", 15.75!, System.Drawing.FontStyle.Bold)
        Me.BunifuLabel2.ForeColor = System.Drawing.Color.Salmon
        Me.BunifuLabel2.Location = New System.Drawing.Point(25, 23)
        Me.BunifuLabel2.Name = "BunifuLabel2"
        Me.BunifuLabel2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel2.Size = New System.Drawing.Size(72, 32)
        Me.BunifuLabel2.TabIndex = 0
        Me.BunifuLabel2.Text = "Friends"
        Me.BunifuLabel2.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.Contact11)
        Me.Panel2.Controls.Add(Me.Contact21)
        Me.Panel2.Controls.Add(Me.Contact31)
        Me.Panel2.Controls.Add(Me.Contact41)
        Me.Panel2.Controls.Add(Me.Contact51)
        Me.Panel2.Controls.Add(Me.Contact61)
        Me.Panel2.Controls.Add(Me.Contact71)
        Me.Panel2.Location = New System.Drawing.Point(757, 38)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(208, 553)
        Me.Panel2.TabIndex = 3
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Panel4.Controls.Add(Me.BunifuLabel1)
        Me.Panel4.Controls.Add(Me.BunifuImageButton1)
        Me.Panel4.Location = New System.Drawing.Point(0, 0)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(965, 41)
        Me.Panel4.TabIndex = 4
        '
        'BunifuLabel1
        '
        Me.BunifuLabel1.AutoEllipsis = False
        Me.BunifuLabel1.CursorType = Nothing
        Me.BunifuLabel1.Font = New System.Drawing.Font("Palatino Linotype", 15.75!, System.Drawing.FontStyle.Bold)
        Me.BunifuLabel1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.BunifuLabel1.Location = New System.Drawing.Point(12, 4)
        Me.BunifuLabel1.Name = "BunifuLabel1"
        Me.BunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel1.Size = New System.Drawing.Size(193, 30)
        Me.BunifuLabel1.TabIndex = 1
        Me.BunifuLabel1.Text = "Bunifu Phonebook"
        Me.BunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        '
        'BunifuImageButton1
        '
        Me.BunifuImageButton1.ActiveImage = Nothing
        Me.BunifuImageButton1.AllowAnimations = True
        Me.BunifuImageButton1.AllowZooming = True
        Me.BunifuImageButton1.BackColor = System.Drawing.Color.Transparent
        Me.BunifuImageButton1.ErrorImage = CType(resources.GetObject("BunifuImageButton1.ErrorImage"), System.Drawing.Image)
        Me.BunifuImageButton1.FadeWhenInactive = False
        Me.BunifuImageButton1.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal
        Me.BunifuImageButton1.Image = CType(resources.GetObject("BunifuImageButton1.Image"), System.Drawing.Image)
        Me.BunifuImageButton1.ImageActive = Nothing
        Me.BunifuImageButton1.ImageLocation = Nothing
        Me.BunifuImageButton1.ImageMargin = 0
        Me.BunifuImageButton1.ImageSize = New System.Drawing.Size(34, 34)
        Me.BunifuImageButton1.ImageZoomSize = New System.Drawing.Size(34, 34)
        Me.BunifuImageButton1.InitialImage = CType(resources.GetObject("BunifuImageButton1.InitialImage"), System.Drawing.Image)
        Me.BunifuImageButton1.Location = New System.Drawing.Point(928, 4)
        Me.BunifuImageButton1.Name = "BunifuImageButton1"
        Me.BunifuImageButton1.Rotation = 0
        Me.BunifuImageButton1.ShowActiveImage = True
        Me.BunifuImageButton1.ShowCursorChanges = True
        Me.BunifuImageButton1.ShowImageBorders = True
        Me.BunifuImageButton1.ShowSizeMarkers = False
        Me.BunifuImageButton1.Size = New System.Drawing.Size(34, 34)
        Me.BunifuImageButton1.TabIndex = 0
        Me.BunifuImageButton1.ToolTipText = "Close"
        Me.BunifuImageButton1.WaitOnLoad = False
        Me.BunifuImageButton1.Zoom = 0
        Me.BunifuImageButton1.ZoomSpeed = 10
        '
        'BunifuFormDock1
        '
        Me.BunifuFormDock1.AllowFormDragging = True
        Me.BunifuFormDock1.AllowFormResizing = False
        Me.BunifuFormDock1.AllowOpacityChangesWhileDragging = False
        Me.BunifuFormDock1.ContainerControl = Me
        Me.BunifuFormDock1.DockingIndicatorsColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(215, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.BunifuFormDock1.DockingIndicatorsOpacity = 0.5R
        Me.BunifuFormDock1.DockingOptions.DockAll = True
        Me.BunifuFormDock1.DockingOptions.DockBottomLeft = True
        Me.BunifuFormDock1.DockingOptions.DockBottomRight = True
        Me.BunifuFormDock1.DockingOptions.DockFullScreen = True
        Me.BunifuFormDock1.DockingOptions.DockLeft = True
        Me.BunifuFormDock1.DockingOptions.DockRight = True
        Me.BunifuFormDock1.DockingOptions.DockTopLeft = True
        Me.BunifuFormDock1.DockingOptions.DockTopRight = True
        Me.BunifuFormDock1.FormDraggingOpacity = 0.9R
        Me.BunifuFormDock1.ParentForm = Me
        Me.BunifuFormDock1.ShowCursorChanges = True
        Me.BunifuFormDock1.ShowDockingIndicators = True
        Me.BunifuFormDock1.TitleBarOptions.AllowFormDragging = True
        Me.BunifuFormDock1.TitleBarOptions.BunifuFormDock = Me.BunifuFormDock1
        Me.BunifuFormDock1.TitleBarOptions.DoubleClickToExpandWindow = True
        Me.BunifuFormDock1.TitleBarOptions.TitleBarControl = Me.Panel4
        Me.BunifuFormDock1.TitleBarOptions.UseBackColorOnDockingIndicators = False
        '
        'Contact11
        '
        Me.Contact11.Location = New System.Drawing.Point(0, 4)
        Me.Contact11.Name = "Contact11"
        Me.Contact11.Size = New System.Drawing.Size(208, 553)
        Me.Contact11.TabIndex = 6
        '
        'Contact21
        '
        Me.Contact21.Location = New System.Drawing.Point(0, 4)
        Me.Contact21.Name = "Contact21"
        Me.Contact21.Size = New System.Drawing.Size(208, 553)
        Me.Contact21.TabIndex = 5
        '
        'Contact31
        '
        Me.Contact31.Location = New System.Drawing.Point(0, 4)
        Me.Contact31.Name = "Contact31"
        Me.Contact31.Size = New System.Drawing.Size(208, 553)
        Me.Contact31.TabIndex = 4
        '
        'Contact41
        '
        Me.Contact41.Location = New System.Drawing.Point(0, 4)
        Me.Contact41.Name = "Contact41"
        Me.Contact41.Size = New System.Drawing.Size(208, 553)
        Me.Contact41.TabIndex = 3
        '
        'Contact51
        '
        Me.Contact51.Location = New System.Drawing.Point(0, 4)
        Me.Contact51.Name = "Contact51"
        Me.Contact51.Size = New System.Drawing.Size(208, 553)
        Me.Contact51.TabIndex = 2
        '
        'Contact61
        '
        Me.Contact61.Location = New System.Drawing.Point(0, 4)
        Me.Contact61.Name = "Contact61"
        Me.Contact61.Size = New System.Drawing.Size(208, 553)
        Me.Contact61.TabIndex = 1
        '
        'Contact71
        '
        Me.Contact71.Location = New System.Drawing.Point(0, 4)
        Me.Contact71.Name = "Contact71"
        Me.Contact71.Size = New System.Drawing.Size(208, 553)
        Me.Contact71.TabIndex = 0
        '
        'AllContacts1
        '
        Me.AllContacts1.Location = New System.Drawing.Point(0, 4)
        Me.AllContacts1.Name = "AllContacts1"
        Me.AllContacts1.Size = New System.Drawing.Size(546, 553)
        Me.AllContacts1.TabIndex = 36
        '
        'AddContact1
        '
        Me.AddContact1.Location = New System.Drawing.Point(-2, 4)
        Me.AddContact1.Name = "AddContact1"
        Me.AddContact1.Size = New System.Drawing.Size(546, 553)
        Me.AddContact1.TabIndex = 35
        '
        'Coworkers1
        '
        Me.Coworkers1.Location = New System.Drawing.Point(0, 4)
        Me.Coworkers1.Name = "Coworkers1"
        Me.Coworkers1.Size = New System.Drawing.Size(546, 553)
        Me.Coworkers1.TabIndex = 34
        '
        'Designers1
        '
        Me.Designers1.Location = New System.Drawing.Point(0, 0)
        Me.Designers1.Name = "Designers1"
        Me.Designers1.Size = New System.Drawing.Size(546, 553)
        Me.Designers1.TabIndex = 33
        '
        'Developers1
        '
        Me.Developers1.Location = New System.Drawing.Point(0, 4)
        Me.Developers1.Name = "Developers1"
        Me.Developers1.Size = New System.Drawing.Size(546, 553)
        Me.Developers1.TabIndex = 32
        '
        'Family1
        '
        Me.Family1.Location = New System.Drawing.Point(0, 4)
        Me.Family1.Name = "Family1"
        Me.Family1.Size = New System.Drawing.Size(546, 553)
        Me.Family1.TabIndex = 31
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(965, 591)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.Panel1.ResumeLayout(False)
        CType(Me.BunifuPictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.BunifuPictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BunifuPictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BunifuPictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BunifuPictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BunifuPictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BunifuPictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BunifuPictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents BunifuImageButton1 As Bunifu.UI.WinForms.BunifuImageButton
    Friend WithEvents BunifuLabel1 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuFormDock1 As Bunifu.UI.WinForms.BunifuFormDock
    Friend WithEvents BunifuImageButton2 As Bunifu.UI.WinForms.BunifuImageButton
    Friend WithEvents BunifuFlatButton6 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton5 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton4 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton3 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton2 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton1 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuPictureBox1 As Bunifu.UI.WinForms.BunifuPictureBox
    Friend WithEvents BunifuImageButton3 As Bunifu.UI.WinForms.BunifuImageButton
    Friend WithEvents BunifuTextBox1 As Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox
    Friend WithEvents BunifuLabel2 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel8 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel7 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel6 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel5 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel4 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel3 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuPictureBox7 As Bunifu.UI.WinForms.BunifuPictureBox
    Friend WithEvents BunifuPictureBox6 As Bunifu.UI.WinForms.BunifuPictureBox
    Friend WithEvents BunifuPictureBox5 As Bunifu.UI.WinForms.BunifuPictureBox
    Friend WithEvents BunifuPictureBox4 As Bunifu.UI.WinForms.BunifuPictureBox
    Friend WithEvents BunifuPictureBox3 As Bunifu.UI.WinForms.BunifuPictureBox
    Friend WithEvents BunifuPictureBox2 As Bunifu.UI.WinForms.BunifuPictureBox
    Friend WithEvents BunifuSeparator7 As Bunifu.Framework.UI.BunifuSeparator
    Friend WithEvents BunifuSeparator6 As Bunifu.Framework.UI.BunifuSeparator
    Friend WithEvents BunifuSeparator5 As Bunifu.Framework.UI.BunifuSeparator
    Friend WithEvents BunifuSeparator4 As Bunifu.Framework.UI.BunifuSeparator
    Friend WithEvents BunifuSeparator3 As Bunifu.Framework.UI.BunifuSeparator
    Friend WithEvents BunifuSeparator2 As Bunifu.Framework.UI.BunifuSeparator
    Friend WithEvents BunifuSeparator1 As Bunifu.Framework.UI.BunifuSeparator
    Friend WithEvents BunifuLabel14 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel13 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel12 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel11 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel10 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel9 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel16 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel15 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuPictureBox8 As Bunifu.UI.WinForms.BunifuPictureBox
    Friend WithEvents Contact11 As Contact1
    Friend WithEvents Contact21 As Contact2
    Friend WithEvents Contact31 As Contact3
    Friend WithEvents Contact41 As Contact4
    Friend WithEvents Contact51 As Contact5
    Friend WithEvents Contact61 As Contact6
    Friend WithEvents Contact71 As Contact7
    Friend WithEvents Coworkers1 As Coworkers
    Friend WithEvents Designers1 As Designers
    Friend WithEvents Developers1 As Developers
    Friend WithEvents Family1 As Family
    Friend WithEvents Panel10 As Panel
    Friend WithEvents Panel9 As Panel
    Friend WithEvents Panel8 As Panel
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents BunifuImageButton4 As Bunifu.UI.WinForms.BunifuImageButton
    Friend WithEvents BunifuImageButton6 As Bunifu.UI.WinForms.BunifuImageButton
    Friend WithEvents AllContacts1 As AllContacts
    Friend WithEvents AddContact1 As AddContact
End Class
