﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Developers
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Developers))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.BunifuImageButton3 = New Bunifu.UI.WinForms.BunifuImageButton()
        Me.BunifuTextBox1 = New Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox()
        Me.BunifuLabel2 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuImageButton5 = New Bunifu.UI.WinForms.BunifuImageButton()
        Me.BunifuCustomDataGrid1 = New Bunifu.Framework.UI.BunifuCustomDataGrid()
        Me.Column1 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.BunifuCustomDataGrid1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BunifuImageButton3
        '
        Me.BunifuImageButton3.ActiveImage = Nothing
        Me.BunifuImageButton3.AllowAnimations = True
        Me.BunifuImageButton3.AllowZooming = True
        Me.BunifuImageButton3.BackColor = System.Drawing.Color.Transparent
        Me.BunifuImageButton3.ErrorImage = CType(resources.GetObject("BunifuImageButton3.ErrorImage"), System.Drawing.Image)
        Me.BunifuImageButton3.FadeWhenInactive = True
        Me.BunifuImageButton3.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal
        Me.BunifuImageButton3.Image = CType(resources.GetObject("BunifuImageButton3.Image"), System.Drawing.Image)
        Me.BunifuImageButton3.ImageActive = Nothing
        Me.BunifuImageButton3.ImageLocation = Nothing
        Me.BunifuImageButton3.ImageMargin = 0
        Me.BunifuImageButton3.ImageSize = New System.Drawing.Size(29, 31)
        Me.BunifuImageButton3.ImageZoomSize = New System.Drawing.Size(29, 31)
        Me.BunifuImageButton3.InitialImage = CType(resources.GetObject("BunifuImageButton3.InitialImage"), System.Drawing.Image)
        Me.BunifuImageButton3.Location = New System.Drawing.Point(505, 14)
        Me.BunifuImageButton3.Name = "BunifuImageButton3"
        Me.BunifuImageButton3.Rotation = 0
        Me.BunifuImageButton3.ShowActiveImage = True
        Me.BunifuImageButton3.ShowCursorChanges = True
        Me.BunifuImageButton3.ShowImageBorders = False
        Me.BunifuImageButton3.ShowSizeMarkers = False
        Me.BunifuImageButton3.Size = New System.Drawing.Size(29, 31)
        Me.BunifuImageButton3.TabIndex = 5
        Me.BunifuImageButton3.ToolTipText = ""
        Me.BunifuImageButton3.WaitOnLoad = False
        Me.BunifuImageButton3.Zoom = 0
        Me.BunifuImageButton3.ZoomSpeed = 10
        '
        'BunifuTextBox1
        '
        Me.BunifuTextBox1.AcceptsReturn = False
        Me.BunifuTextBox1.AcceptsTab = False
        Me.BunifuTextBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.BunifuTextBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.BunifuTextBox1.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTextBox1.BackgroundImage = CType(resources.GetObject("BunifuTextBox1.BackgroundImage"), System.Drawing.Image)
        Me.BunifuTextBox1.BorderColorActive = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.BunifuTextBox1.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(161, Byte), Integer))
        Me.BunifuTextBox1.BorderColorHover = System.Drawing.Color.Teal
        Me.BunifuTextBox1.BorderColorIdle = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(107, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.BunifuTextBox1.BorderRadius = 25
        Me.BunifuTextBox1.BorderThickness = 1
        Me.BunifuTextBox1.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.BunifuTextBox1.DefaultFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuTextBox1.DefaultText = ""
        Me.BunifuTextBox1.FillColor = System.Drawing.Color.White
        Me.BunifuTextBox1.HideSelection = True
        Me.BunifuTextBox1.IconLeft = Nothing
        Me.BunifuTextBox1.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.BunifuTextBox1.IconPadding = 10
        Me.BunifuTextBox1.IconRight = CType(resources.GetObject("BunifuTextBox1.IconRight"), System.Drawing.Image)
        Me.BunifuTextBox1.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.BunifuTextBox1.Location = New System.Drawing.Point(176, 29)
        Me.BunifuTextBox1.MaxLength = 32767
        Me.BunifuTextBox1.MinimumSize = New System.Drawing.Size(80, 20)
        Me.BunifuTextBox1.Modified = False
        Me.BunifuTextBox1.Name = "BunifuTextBox1"
        Me.BunifuTextBox1.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.BunifuTextBox1.ReadOnly = False
        Me.BunifuTextBox1.SelectedText = ""
        Me.BunifuTextBox1.SelectionLength = 0
        Me.BunifuTextBox1.SelectionStart = 0
        Me.BunifuTextBox1.ShortcutsEnabled = True
        Me.BunifuTextBox1.Size = New System.Drawing.Size(208, 28)
        Me.BunifuTextBox1.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu
        Me.BunifuTextBox1.TabIndex = 4
        Me.BunifuTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.BunifuTextBox1.TextMarginLeft = 5
        Me.BunifuTextBox1.TextPlaceholder = "Search"
        Me.BunifuTextBox1.UseSystemPasswordChar = False
        '
        'BunifuLabel2
        '
        Me.BunifuLabel2.AutoEllipsis = False
        Me.BunifuLabel2.CursorType = Nothing
        Me.BunifuLabel2.Font = New System.Drawing.Font("Yu Gothic UI", 15.75!, System.Drawing.FontStyle.Bold)
        Me.BunifuLabel2.ForeColor = System.Drawing.Color.Salmon
        Me.BunifuLabel2.Location = New System.Drawing.Point(40, 29)
        Me.BunifuLabel2.Name = "BunifuLabel2"
        Me.BunifuLabel2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel2.Size = New System.Drawing.Size(110, 32)
        Me.BunifuLabel2.TabIndex = 3
        Me.BunifuLabel2.Text = "Developers"
        Me.BunifuLabel2.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        '
        'BunifuImageButton5
        '
        Me.BunifuImageButton5.ActiveImage = Nothing
        Me.BunifuImageButton5.AllowAnimations = True
        Me.BunifuImageButton5.AllowZooming = True
        Me.BunifuImageButton5.BackColor = System.Drawing.Color.Transparent
        Me.BunifuImageButton5.ErrorImage = CType(resources.GetObject("BunifuImageButton5.ErrorImage"), System.Drawing.Image)
        Me.BunifuImageButton5.FadeWhenInactive = False
        Me.BunifuImageButton5.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal
        Me.BunifuImageButton5.Image = CType(resources.GetObject("BunifuImageButton5.Image"), System.Drawing.Image)
        Me.BunifuImageButton5.ImageActive = Nothing
        Me.BunifuImageButton5.ImageLocation = Nothing
        Me.BunifuImageButton5.ImageMargin = 0
        Me.BunifuImageButton5.ImageSize = New System.Drawing.Size(17, 19)
        Me.BunifuImageButton5.ImageZoomSize = New System.Drawing.Size(17, 19)
        Me.BunifuImageButton5.InitialImage = CType(resources.GetObject("BunifuImageButton5.InitialImage"), System.Drawing.Image)
        Me.BunifuImageButton5.Location = New System.Drawing.Point(390, 38)
        Me.BunifuImageButton5.Name = "BunifuImageButton5"
        Me.BunifuImageButton5.Rotation = 0
        Me.BunifuImageButton5.ShowActiveImage = True
        Me.BunifuImageButton5.ShowCursorChanges = True
        Me.BunifuImageButton5.ShowImageBorders = False
        Me.BunifuImageButton5.ShowSizeMarkers = False
        Me.BunifuImageButton5.Size = New System.Drawing.Size(17, 19)
        Me.BunifuImageButton5.TabIndex = 40
        Me.BunifuImageButton5.ToolTipText = "Delete"
        Me.BunifuImageButton5.WaitOnLoad = False
        Me.BunifuImageButton5.Zoom = 0
        Me.BunifuImageButton5.ZoomSpeed = 10
        '
        'BunifuCustomDataGrid1
        '
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.BunifuCustomDataGrid1.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.BunifuCustomDataGrid1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.BunifuCustomDataGrid1.BackgroundColor = System.Drawing.Color.Gainsboro
        Me.BunifuCustomDataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.BunifuCustomDataGrid1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.BunifuCustomDataGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.Salmon
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.Salmon
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.BunifuCustomDataGrid1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.BunifuCustomDataGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.BunifuCustomDataGrid1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column4, Me.Column5})
        Me.BunifuCustomDataGrid1.DoubleBuffered = True
        Me.BunifuCustomDataGrid1.EnableHeadersVisualStyles = False
        Me.BunifuCustomDataGrid1.HeaderBgColor = System.Drawing.Color.Salmon
        Me.BunifuCustomDataGrid1.HeaderForeColor = System.Drawing.Color.Salmon
        Me.BunifuCustomDataGrid1.Location = New System.Drawing.Point(15, 75)
        Me.BunifuCustomDataGrid1.Name = "BunifuCustomDataGrid1"
        Me.BunifuCustomDataGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.BunifuCustomDataGrid1.RowHeadersVisible = False
        Me.BunifuCustomDataGrid1.Size = New System.Drawing.Size(519, 475)
        Me.BunifuCustomDataGrid1.TabIndex = 43
        '
        'Column1
        '
        Me.Column1.HeaderText = "Image"
        Me.Column1.Name = "Column1"
        '
        'Column2
        '
        Me.Column2.HeaderText = "Name"
        Me.Column2.Name = "Column2"
        '
        'Column3
        '
        Me.Column3.HeaderText = "Contact no."
        Me.Column3.Name = "Column3"
        '
        'Column4
        '
        Me.Column4.HeaderText = "Country"
        Me.Column4.Name = "Column4"
        '
        'Column5
        '
        Me.Column5.HeaderText = "State"
        Me.Column5.Name = "Column5"
        '
        'Developers
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.BunifuCustomDataGrid1)
        Me.Controls.Add(Me.BunifuImageButton5)
        Me.Controls.Add(Me.BunifuImageButton3)
        Me.Controls.Add(Me.BunifuTextBox1)
        Me.Controls.Add(Me.BunifuLabel2)
        Me.Name = "Developers"
        Me.Size = New System.Drawing.Size(546, 553)
        CType(Me.BunifuCustomDataGrid1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents BunifuImageButton3 As Bunifu.UI.WinForms.BunifuImageButton
    Friend WithEvents BunifuTextBox1 As Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox
    Friend WithEvents BunifuLabel2 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuImageButton5 As Bunifu.UI.WinForms.BunifuImageButton
    Friend WithEvents BunifuCustomDataGrid1 As Bunifu.Framework.UI.BunifuCustomDataGrid
    Friend WithEvents Column1 As DataGridViewImageColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
End Class
