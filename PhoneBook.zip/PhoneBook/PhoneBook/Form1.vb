﻿Public Class Form1
    Private Sub BunifuImageButton1_Click(sender As Object, e As EventArgs) Handles BunifuImageButton1.Click
        Me.Close()
    End Sub

    Private Sub BunifuLabel3_Click(sender As Object, e As EventArgs) Handles BunifuLabel3.Click
        Contact11.Hide()
        Contact21.Show()
        Contact31.Hide()
        Contact41.Hide()
        Contact51.Hide()
        Contact61.Hide()
        Contact71.Hide()

    End Sub

    Private Sub BunifuLabel4_Click(sender As Object, e As EventArgs) Handles BunifuLabel4.Click
        Contact11.Show()
        Contact21.Hide()
        Contact31.Hide()
        Contact41.Hide()
        Contact51.Hide()
        Contact61.Hide()
        Contact71.Hide()
    End Sub

    Private Sub BunifuLabel5_Click(sender As Object, e As EventArgs) Handles BunifuLabel5.Click
        Contact11.Hide()
        Contact21.Hide()
        Contact31.Show()
        Contact41.Hide()
        Contact51.Hide()
        Contact61.Hide()
        Contact71.Hide()
    End Sub

    Private Sub BunifuLabel6_Click(sender As Object, e As EventArgs) Handles BunifuLabel6.Click
        Contact11.Hide()
        Contact21.Hide()
        Contact31.Hide()
        Contact41.Show()
        Contact51.Hide()
        Contact61.Hide()
        Contact71.Hide()
    End Sub

    Private Sub BunifuLabel7_Click(sender As Object, e As EventArgs) Handles BunifuLabel7.Click
        Contact11.Hide()
        Contact21.Hide()
        Contact31.Hide()
        Contact41.Hide()
        Contact51.Show()
        Contact61.Hide()
        Contact71.Hide()
    End Sub

    Private Sub BunifuLabel8_Click(sender As Object, e As EventArgs) Handles BunifuLabel8.Click
        Contact11.Hide()
        Contact21.Hide()
        Contact31.Hide()
        Contact41.Hide()
        Contact51.Hide()
        Contact61.Show()
        Contact71.Hide()
    End Sub

    Private Sub BunifuLabel15_Click(sender As Object, e As EventArgs) Handles BunifuLabel15.Click
        Contact11.Hide()
        Contact21.Hide()
        Contact31.Hide()
        Contact41.Hide()
        Contact51.Hide()
        Contact61.Hide()
        Contact71.Show()
        Panel5.Hide()
        Panel6.Hide()
        Panel7.Hide()
        Panel8.Hide()
        Panel9.Hide()
        Panel10.Hide()
    End Sub

    Private Sub BunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton1.Click
        AllContacts1.Show()
        Coworkers1.Hide()
        Designers1.Hide()
        Developers1.Hide()
        Family1.Hide()
        AddContact1.Hide()
        Contact11.Hide()
        Contact21.Hide()
        Contact31.Hide()
        Contact41.Hide()
        Contact51.Hide()
        Contact61.Hide()
        Contact71.Hide()
        Panel5.Show()
        Panel6.Hide()
        Panel7.Hide()
        Panel8.Hide()
        Panel9.Hide()
        Panel10.Hide()
    End Sub

    Private Sub BunifuFlatButton2_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton2.Click
        AllContacts1.Hide()
        Coworkers1.Hide()
        Designers1.Hide()
        Developers1.Hide()
        Family1.Hide()
        AddContact1.Hide()
        Panel5.Hide()
        Panel6.Show()
        Panel7.Hide()
        Panel8.Hide()
        Panel9.Hide()
        Panel10.Hide()
    End Sub

    Private Sub BunifuFlatButton3_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton3.Click
        AllContacts1.Hide()
        Coworkers1.Show()
        Designers1.Hide()
        Developers1.Hide()
        Family1.Hide()
        AddContact1.Hide()
        Contact11.Hide()
        Contact21.Hide()
        Contact31.Hide()
        Contact41.Hide()
        Contact51.Hide()
        Contact61.Hide()
        Contact71.Hide()
        Panel5.Hide()
        Panel6.Hide()
        Panel7.Show()
        Panel8.Hide()
        Panel9.Hide()
        Panel10.Hide()
    End Sub

    Private Sub BunifuFlatButton4_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton4.Click
        AllContacts1.Hide()
        Coworkers1.Hide()
        Designers1.Show()
        Developers1.Hide()
        Family1.Hide()
        AddContact1.Hide()
        Contact11.Hide()
        Contact21.Hide()
        Contact31.Hide()
        Contact41.Hide()
        Contact51.Hide()
        Contact61.Hide()
        Contact71.Hide()
        Panel5.Hide()
        Panel6.Hide()
        Panel7.Hide()
        Panel8.Show()
        Panel9.Hide()
        Panel10.Hide()
    End Sub

    Private Sub BunifuFlatButton5_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton5.Click
        AllContacts1.Hide()
        Coworkers1.Hide()
        Designers1.Hide()
        Developers1.Show()
        Family1.Hide()
        AddContact1.Hide()
        Contact11.Hide()
        Contact21.Hide()
        Contact31.Hide()
        Contact41.Hide()
        Contact51.Hide()
        Contact61.Hide()
        Contact71.Hide()
        Panel5.Hide()
        Panel6.Hide()
        Panel7.Hide()
        Panel8.Hide()
        Panel9.Show()
        Panel10.Hide()
    End Sub

    Private Sub BunifuFlatButton6_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton6.Click
        AllContacts1.Hide()
        Coworkers1.Hide()
        Designers1.Hide()
        Developers1.Hide()
        Family1.Show()
        AddContact1.Hide()
        Contact11.Hide()
        Contact21.Hide()
        Contact31.Hide()
        Contact41.Hide()
        Contact51.Hide()
        Contact61.Hide()
        Contact71.Hide()
        Panel5.Hide()
        Panel6.Hide()
        Panel7.Hide()
        Panel8.Hide()
        Panel9.Hide()
        Panel10.Show()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Panel5.Show()
        Panel6.Hide()
        Panel7.Hide()
        Panel8.Hide()
        Panel9.Hide()
        Panel10.Hide()
        Contact11.Hide()
        Contact21.Hide()
        Contact31.Hide()
        Contact41.Hide()
        Contact51.Hide()
        Contact61.Hide()
        Contact71.Hide()

    End Sub

    Private Sub BunifuImageButton4_Click(sender As Object, e As EventArgs) Handles BunifuImageButton4.Click
        AddContact1.Show()
        Panel5.Hide()
        Panel6.Hide()
        Panel7.Hide()
        Panel8.Hide()
        Panel9.Hide()
        Panel10.Hide()
        Contact11.Hide()
        Contact21.Hide()
        Contact31.Hide()
        Contact41.Hide()
        Contact51.Hide()
        Contact61.Hide()
        Contact71.Hide()
        AllContacts1.Hide()
        Coworkers1.Hide()
        Designers1.Hide()
        Developers1.Hide()
        Family1.Hide()
    End Sub
End Class
