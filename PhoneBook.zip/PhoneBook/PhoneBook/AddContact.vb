﻿Imports System.IO
Imports MySql.Data.MySqlClient
Public Class AddContact
    Dim MysqlConn As MySqlConnection
    Dim command As MySqlCommand

    Private Sub BunifuLabel1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub BunifuButton2_Click(sender As Object, e As EventArgs) Handles BunifuButton2.Click
        If BunifuTextBox1.Text.Length = 0 Then
            lblerror.Visible = True
            lblerror.Text = "Field can't be empty!"

            BunifuTextBox1.Focus()
        ElseIf BunifuTextBox2.Text.Length = 0 Then
            lblerror.Visible = True
            lblerror.Text = "Field can't be empty!"
            BunifuTextBox2.Focus()


        ElseIf BunifuTextBox3.Text.Length = 0 Then
            lblerror.Visible = True
            lblerror.Text = "Field can't be empty!"
            BunifuTextBox3.Focus()

        ElseIf BunifuTextBox4.Text.Length = 0 Then
            lblerror.Visible = True
            lblerror.Text = "Field can't be empty!"
            BunifuTextBox4.Focus()
        Else

            MysqlConn = New MySqlConnection
            MysqlConn.ConnectionString = " datasource=127.0.0.1;port=3306;user=root;password=;database=bunifuphonebook;SslMode=none"
            Dim ms As New MemoryStream
            BunifuPictureBox1.Image.Save(ms, BunifuPictureBox1.Image.RawFormat)
            Dim command As New MySqlCommand("insert into users(image,name,contact,country,state)values(@im,@nm,@cn,@co,@st)", MysqlConn)
            command.Parameters.Add("@im", MySqlDbType.Blob).Value = ms.ToArray()
            command.Parameters.Add("@nm", MySqlDbType.Blob).Value = BunifuTextBox1.Text
            command.Parameters.Add("@cn", MySqlDbType.Blob).Value = BunifuTextBox2.Text
            command.Parameters.Add("@co", MySqlDbType.Blob).Value = BunifuTextBox3.Text
            command.Parameters.Add("@st", MySqlDbType.Blob).Value = BunifuTextBox4.Text
            MysqlConn.Open()
            If command.ExecuteNonQuery() = 1 Then
                MessageBox.Show("Added Successfully")
            Else
                MessageBox.Show("Error Occured")
            End If
            BunifuTextBox1.Text = ""
            BunifuTextBox2.Text = ""
            BunifuTextBox3.Text = ""
            BunifuTextBox4.Text = ""
            BunifuPictureBox1.Image = Nothing
            MysqlConn.Close()
        End If
    End Sub

    Private Sub BunifuButton1_Click(sender As Object, e As EventArgs) Handles BunifuButton1.Click
        Dim opf As New OpenFileDialog
        opf.Filter = "Choose Image(*.JPG;*.PNG;*.GIF)|*jpg;*.png;*.gif"
        If opf.ShowDialog = System.Windows.Forms.DialogResult.OK Then
            BunifuPictureBox1.Image = Image.FromFile(opf.FileName)
        End If
    End Sub

    Private Sub AddContact_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblerror.Visible = False
    End Sub
End Class
